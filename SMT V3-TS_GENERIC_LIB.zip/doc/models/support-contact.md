
# Support Contact

## Structure

`SupportContact`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | - |
| `email` | `string` | Required | - |
| `phone` | `string` | Required | - |

## Example (as JSON)

```json
{
  "name": "",
  "email": "",
  "phone": ""
}
```

