
# Toggle Sub Asset Types Request

## Structure

`ToggleSubAssetTypesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string` | Required | - |
| `assetCategoryId` | `string` | Required | - |
| `assetTypeId` | `string` | Required | - |

## Example (as JSON)

```json
{
  "status": "Y",
  "assetCategoryId": "ALL",
  "assetTypeId": "ALL"
}
```

