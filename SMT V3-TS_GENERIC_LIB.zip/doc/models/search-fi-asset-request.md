
# Search Fi Asset Request

## Structure

`SearchFiAssetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `term` | `string` | Required | - |
| `limit` | `number` | Required | - |
| `skip` | `number` | Required | - |

## Example (as JSON)

```json
{
  "term": "first",
  "limit": 5,
  "skip": 0
}
```

