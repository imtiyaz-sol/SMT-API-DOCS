
# Get Historical Collection Request

## Structure

`GetHistoricalCollectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `meters` | `string[]` | Required | - |

## Example (as JSON)

```json
{
  "meters": [
    "1263036"
  ]
}
```

