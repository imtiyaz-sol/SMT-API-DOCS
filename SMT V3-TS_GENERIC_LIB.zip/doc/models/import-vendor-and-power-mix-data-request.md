
# Import Vendor and Power Mix Data Request

## Structure

`ImportVendorAndPowerMixDataRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vendorInfo` | [`VendorInfo`](../../doc/models/vendor-info.md) | Required | - |

## Example (as JSON)

```json
{
  "vendorInfo": {
    "manufacturerName": "Bermuda Electric Light Company",
    "state": "Hamilton"
  }
}
```

