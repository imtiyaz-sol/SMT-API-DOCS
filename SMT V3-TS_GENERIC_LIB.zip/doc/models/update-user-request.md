
# Update User Request

## Structure

`UpdateUserRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userId` | `string` | Required | - |
| `permissionId` | `string` | Required | - |
| `email` | `string` | Required | - |
| `assetId` | `string` | Required | - |

## Example (as JSON)

```json
{
  "userId": "E11D8EC62964DE8C0EAF967E432CEC01",
  "permissionId": "99D2C25E64D8F2A0AF77976D39191B10",
  "email": "Varshilshah444@gmail.com",
  "assetId": "62662df11c119c2164badd10"
}
```

