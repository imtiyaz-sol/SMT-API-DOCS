
# Dashboard API Request

## Structure

`DashboardAPIRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `configurationIds` | `string[]` | Required | - |
| `reportingAssetIds` | `string[]` | Required | - |

## Example (as JSON)

```json
{
  "configurationIds": [
    "B4682109C13EDDDD1CB19EFBF52D690D"
  ],
  "reportingAssetIds": []
}
```

