
# Link Fi Assets to Solulab Assets Request

## Structure

`LinkFiAssetsToSolulabAssetsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fiAssetId` | `string` | Required | - |
| `solulabAssetId` | `string` | Required | - |

## Example (as JSON)

```json
{
  "fiAssetId": "98631443238BF8B758192B346D1CD507",
  "SolulabAssetId": "621cb3584de2263358dcc484"
}
```

