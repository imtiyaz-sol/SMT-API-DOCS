
# Total

## Structure

`Total`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `total1` | [`Total1 \| undefined`](../../doc/models/total-1.md) | Optional | - |
| `total2` | [`Total1 \| undefined`](../../doc/models/total-1.md) | Optional | - |

## Example (as JSON)

```json
{
  "total1": {
    "total": 100,
    "coal": 0
  },
  "total2": {
    "total": 202,
    "coal": 228
  }
}
```

