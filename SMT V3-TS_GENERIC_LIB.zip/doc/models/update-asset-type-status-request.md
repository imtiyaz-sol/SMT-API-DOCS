
# Update Asset Type Status Request

## Structure

`UpdateAssetTypeStatusRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string` | Required | - |
| `assetTypeId` | `string` | Required | - |

## Example (as JSON)

```json
{
  "status": "Y",
  "assetTypeId": "6218a649dc5e3735ec198cb1"
}
```

