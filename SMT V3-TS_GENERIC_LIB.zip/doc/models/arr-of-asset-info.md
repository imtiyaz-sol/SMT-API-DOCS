
# Arr of Asset Info

## Structure

`ArrOfAssetInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `configurationId` | `string \| undefined` | Optional | - |
| `action` | `string` | Required | - |
| `assetId` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "configurationId": "64034a413045cc3a80156c7c",
  "action": "DELETE",
  "assetId": "assetId4"
}
```

