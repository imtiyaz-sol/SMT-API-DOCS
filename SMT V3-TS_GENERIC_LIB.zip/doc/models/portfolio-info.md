
# Portfolio Info

## Structure

`PortfolioInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `isChanges` | `boolean` | Required | - |
| `portfolioName` | `string` | Required | - |

## Example (as JSON)

```json
{
  "isChanges": true,
  "portfolioName": "test update 123"
}
```

