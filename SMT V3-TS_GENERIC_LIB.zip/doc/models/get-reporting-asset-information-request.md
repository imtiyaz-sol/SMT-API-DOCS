
# Get Reporting Asset Information Request

## Structure

`GetReportingAssetInformationRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Required | - |

## Example (as JSON)

```json
{
  "_id": "6218aa740c8a5f3f5ccbe844"
}
```

