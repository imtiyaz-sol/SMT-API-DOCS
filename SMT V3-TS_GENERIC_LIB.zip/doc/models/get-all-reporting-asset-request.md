
# Get All Reporting Asset Request

## Structure

`GetAllReportingAssetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `configurationIds` | `string[]` | Required | - |
| `reportingAssetIds` | `string[]` | Required | - |

## Example (as JSON)

```json
{
  "configurationIds": [
    "63d25c05e27fab3c669c5718"
  ],
  "reportingAssetIds": [
    "6218aa740c8a5f3f5ccbe844",
    "62662df11c119c2164badd65",
    "62662df11c119c2164badd1e"
  ]
}
```

