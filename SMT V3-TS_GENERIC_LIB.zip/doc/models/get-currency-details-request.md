
# Get Currency Details Request

## Structure

`GetCurrencyDetailsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reportingAssetId` | `string` | Required | - |
| `vendorId` | `string` | Required | - |
| `productId` | `string` | Required | - |
| `accountId` | `string` | Required | - |

## Example (as JSON)

```json
{
  "reportingAssetId": "62662df11c119c2164badd10",
  "vendorId": "63da971eaeee1d2f645d352d",
  "productId": "63da524c64b6d636b88e9724",
  "accountId": "12323243534"
}
```

