
# Create Io T Manufacturer Request

## Structure

`CreateIoTManufacturerRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `manufacturerName` | `string` | Required | - |

## Example (as JSON)

```json
{
  "manufacturerName": "kavin surya"
}
```

