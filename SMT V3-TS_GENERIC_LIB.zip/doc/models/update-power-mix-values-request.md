
# Update Power Mix Values Request

## Structure

`UpdatePowerMixValuesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `powerId` | `string` | Required | - |
| `totals` | [`Total[]`](../../doc/models/total.md) | Required | - |

## Example (as JSON)

```json
{
  "powerId": "63ff0f0fe84c9f1c0cf7d72b",
  "totals": [
    {
      "total1": {
        "total": 100,
        "coal": 0
      },
      "total2": {
        "total": 202,
        "coal": 228
      }
    },
    {
      "total2": {
        "total": 100,
        "coal": 0
      },
      "total1": {
        "total": 214,
        "coal": 132
      }
    }
  ]
}
```

