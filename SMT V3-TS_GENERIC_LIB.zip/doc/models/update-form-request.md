
# Update Form Request

## Structure

`UpdateFormRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `disabled` | `boolean` | Required | - |

## Example (as JSON)

```json
{
  "disabled": false
}
```

