
# Total 1

## Structure

`Total1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `total` | `number` | Required | - |
| `coal` | `number` | Required | - |

## Example (as JSON)

```json
{
  "total": 100,
  "coal": 0
}
```

