
# Update Authorization Request

## Structure

`UpdateAuthorizationRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `nickname` | `string` | Required | - |

## Example (as JSON)

```json
{
  "nickname": "Test authorization"
}
```

