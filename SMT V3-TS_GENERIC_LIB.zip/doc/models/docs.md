
# Docs

## Structure

`Docs`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `apiDoc` | `string` | Required | - |
| `apiLink` | `string` | Required | - |
| `legalDoc` | `string` | Required | - |

## Example (as JSON)

```json
{
  "apiDoc": "uploads/dummy-1682064978386.pdf",
  "apiLink": "https://www.test.com",
  "legalDoc": "uploads/dummy-1682064985447.pdf"
}
```

