
# Create Production Unit Request

## Structure

`CreateProductionUnitRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `unit` | `string` | Required | - |
| `vendorListId` | `string` | Required | - |

## Example (as JSON)

```json
{
  "unit": "mT",
  "vendorListId": "63cf8f115e37e4f4f71b29fd"
}
```

