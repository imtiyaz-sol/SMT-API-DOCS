
# Search Reporting Asset Request

## Structure

`SearchReportingAssetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `term` | `string` | Required | - |
| `limit` | `number` | Required | - |
| `skip` | `number` | Required | - |

## Example (as JSON)

```json
{
  "term": "first",
  "limit": 5,
  "skip": 0
}
```

