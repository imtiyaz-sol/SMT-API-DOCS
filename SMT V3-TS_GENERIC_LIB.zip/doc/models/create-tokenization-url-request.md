
# Create Tokenization URL Request

## Structure

`CreateTokenizationURLRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `iFrameUrl` | `string` | Required | - |
| `configurationIds` | `string[]` | Required | - |

## Example (as JSON)

```json
{
  "iFrameUrl": "https://digital.bctriangle.com:447/iframecontent/meterListing?options=All&token=eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZXN0IjoidGhpcyBpcyB0ZXN0IGRhdGEiLCJjcmVhdGVkIjoiMTY0NzQ0MTA0NSIsImlhdCI6MTY0NzQ0MTA0NX0.OiLq2em6s9EDXze9XplDLeTtg6QzDbfELBpN4agqmCNUajuKLX-oMVr2ZtjB-jQewXVFvj56_B1m7iNRm3mhtbY9i579poAcuv0RGjs061eFFY6w_fTPXi-PhT-mRJXpVsH5-fXgYmGxrA3l-L0omO0J7XrCXIou58jgSaIo8svRzqJK7toW8FsLufDSZ_MghTANO0wNpN4iXedwIEgG3TmfltSEaqVlEWq13ddrFKIMkzhttoAWyOGTU68EXbQT7mvm2TxgLEXijstN19iP5lZJvuNtXlRVtu2O7dPM9Ro0qzEDgPMzxYditawTeDxc3vaodID2IMAFniASzWq3Zw",
  "configurationIds": [
    "636258afeff65b05c85b43e4",
    "63a1f336df3fc13935624666"
  ]
}
```

