
# Portfolio Configuration Info

## Structure

`PortfolioConfigurationInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `isChanges` | `boolean` | Required | - |
| `arrOfAssetInfo` | [`ArrOfAssetInfo[]`](../../doc/models/arr-of-asset-info.md) | Required | - |

## Example (as JSON)

```json
{
  "isChanges": true,
  "arrOfAssetInfo": [
    {
      "configurationId": "64034a413045cc3a80156c7c",
      "action": "DELETE",
      "assetId": "assetId4"
    },
    {
      "action": "CREATE",
      "assetId": "45CF4F54D3219242EDE4C6F721E6DCA0",
      "configurationId": "configurationId8"
    }
  ]
}
```

