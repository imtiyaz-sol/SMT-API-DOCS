
# Toggle Asset Categories Request

## Structure

`ToggleAssetCategoriesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string` | Required | - |

## Example (as JSON)

```json
{
  "status": "Y"
}
```

