
# Asset Performance Request

## Structure

`AssetPerformanceRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fiAssetId` | `string` | Required | - |

## Example (as JSON)

```json
{
  "fiAssetId": "1C67ECEDB2969E52E03F6472A60A577C"
}
```

