
# Bill Info

## Structure

`BillInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productionUnitId` | `string` | Required | - |
| `billTotal` | `string` | Required | - |
| `productId` | `string` | Required | - |
| `accountNumber` | `number` | Required | - |

## Example (as JSON)

```json
{
  "productionUnitId": "63da9f3e535c66a30db7dda8",
  "billTotal": "454545",
  "productId": "63da524c64b6d636b88e9724",
  "accountNumber": 800863859
}
```

