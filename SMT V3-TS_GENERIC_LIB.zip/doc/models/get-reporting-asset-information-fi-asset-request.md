
# Get Reporting Asset Information Fi Asset Request

## Structure

`GetReportingAssetInformationFiAssetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reportingAssetNameId` | `string` | Required | - |

## Example (as JSON)

```json
{
  "reportingAssetNameId": "62662df11c119c2164badd10"
}
```

