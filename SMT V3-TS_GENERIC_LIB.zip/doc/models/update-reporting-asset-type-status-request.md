
# Update Reporting Asset Type Status Request

## Structure

`UpdateReportingAssetTypeStatusRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string` | Required | - |
| `assetId` | `string` | Required | - |

## Example (as JSON)

```json
{
  "status": "Y",
  "assetId": "62662df11c119c2164badd26"
}
```

