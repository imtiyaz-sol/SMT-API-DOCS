
# Update Fi Asset Information Request

## Structure

`UpdateFiAssetInformationRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fiAssetId` | `string` | Required | - |
| `fiAssetData` | `unknown` | Required | - |

## Example (as JSON)

```json
{
  "fiAssetId": "",
  "fiAssetData": {}
}
```

