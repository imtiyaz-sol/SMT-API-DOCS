
# Create Form Request

## Structure

`CreateFormRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `templateUid` | `string` | Required | - |
| `authorizationUid` | `string` | Required | - |
| `customerEmail` | `string` | Required | - |
| `utility` | `string` | Required | - |

## Example (as JSON)

```json
{
  "template_uid": "1b4ba653",
  "authorization_uid": "241554",
  "customer_email": "kavinsurya@solulab.co",
  "utility": "ConEd"
}
```

