
# Toggle Asset Types Request

## Structure

`ToggleAssetTypesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string` | Required | - |
| `assetCategoryId` | `string` | Required | - |

## Example (as JSON)

```json
{
  "status": "Y",
  "assetCategoryId": "ALL"
}
```

