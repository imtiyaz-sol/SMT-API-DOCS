
# Update Io T Manufacture Status Request

## Structure

`UpdateIoTManufactureStatusRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `manufacturerId` | `string` | Required | - |
| `status` | `string` | Required | - |

## Example (as JSON)

```json
{
  "manufacturerId": "644bb4b43718e16175e8c317",
  "status": "Accepted"
}
```

