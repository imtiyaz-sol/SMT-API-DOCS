
# Create Portfolio Configuration List Request

## Structure

`CreatePortfolioConfigurationListRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userId` | `string` | Required | - |
| `portfolioName` | `string` | Required | - |
| `arrofAssetId` | `string[]` | Required | - |

## Example (as JSON)

```json
{
  "userId": "8CB9348B055D25607AD45674CBF20A12",
  "portfolioName": "Test ID 1",
  "arrofAssetId": [
    "080E329276C3D1FF06A344AEB0B15129",
    "213D976EFBA2697E095CE58145F8F4AE",
    "C3354D58AA67E6C1CF29D6FB43EC177F"
  ]
}
```

