
# Manage Products Request

## Structure

`ManageProductsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `manufacturerId` | `string` | Required | - |
| `productId` | `string` | Required | - |
| `manageFlag` | `boolean` | Required | - |

## Example (as JSON)

```json
{
  "manufacturerId": "63da971eaeee1d2f645d352d",
  "productId": "63da525764b6d636b88e9728",
  "manageFlag": false
}
```

