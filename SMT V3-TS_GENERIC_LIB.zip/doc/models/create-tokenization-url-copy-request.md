
# Create Tokenization URL Copy Request

## Structure

`CreateTokenizationURLCopyRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `arrAssetCategories` | `string[]` | Required | - |
| `arrAssetTypes` | `string[]` | Required | - |
| `arrSubAssetTypes` | `string[]` | Required | - |

## Example (as JSON)

```json
{
  "arrAssetCategories": [],
  "arrAssetTypes": [],
  "arrSubAssetTypes": []
}
```

