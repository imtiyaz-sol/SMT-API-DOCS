
# Createrequest

## Structure

`Createrequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firstName` | `string` | Required | - |
| `lastName` | `string` | Required | - |
| `email` | `string` | Required | - |
| `countryCode` | `string` | Required | - |
| `phone` | `string` | Required | - |
| `permissionId` | `string` | Required | - |
| `assetId` | `string` | Required | - |

## Example (as JSON)

```json
{
  "firstName": "Varshil",
  "lastName": "Shah",
  "email": "Varshilshah444@gmail.com",
  "countryCode": "+91",
  "phone": "9428712306",
  "permissionId": "B66784D18DBDA9EE962B52701DE014F7",
  "assetId": "62662df11c119c2164badd10"
}
```

