
# Create Vendor Request

## Structure

`CreateVendorRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vendorInfo` | [`VendorInfo`](../../doc/models/vendor-info.md) | Required | - |

## Example (as JSON)

```json
{
  "vendorInfo": {
    "manufacturerName": "Bermuda Electric Light Company",
    "state": "Hamilton"
  }
}
```

