
# Update Meter Request

## Structure

`UpdateMeterRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `isArchived` | `boolean` | Required | - |

## Example (as JSON)

```json
{
  "is_archived": false
}
```

