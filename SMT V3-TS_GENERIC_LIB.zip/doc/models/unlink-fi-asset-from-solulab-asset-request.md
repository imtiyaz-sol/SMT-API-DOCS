
# Unlink Fi Asset From Solulab Asset Request

## Structure

`UnlinkFiAssetFromSolulabAssetRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `solulabAssetId` | `string` | Required | - |

## Example (as JSON)

```json
{
  "SolulabAssetId": "6215dcbf321bae24f4a1bb75"
}
```

