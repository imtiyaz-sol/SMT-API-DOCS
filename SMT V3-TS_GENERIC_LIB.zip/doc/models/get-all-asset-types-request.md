
# Get All Asset Types Request

## Structure

`GetAllAssetTypesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `configurationIds` | `string[]` | Required | - |

## Example (as JSON)

```json
{
  "configurationIds": [
    "0A8DF46C22B8009EF2B32EB92D231C7E"
  ]
}
```

