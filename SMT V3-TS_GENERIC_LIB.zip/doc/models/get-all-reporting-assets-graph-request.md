
# Get All Reporting Assets Graph Request

## Structure

`GetAllReportingAssetsGraphRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `assetTypesId` | `string` | Required | - |

## Example (as JSON)

```json
{
  "assetTypesId": "6218a64adc5e3735ec198cfd"
}
```

