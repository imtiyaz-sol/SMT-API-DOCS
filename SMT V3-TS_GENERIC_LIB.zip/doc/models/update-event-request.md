
# Update Event Request

## Structure

`UpdateEventRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `isDelivered` | `boolean` | Required | - |

## Example (as JSON)

```json
{
  "is_delivered": false
}
```

