
# Create Product Service Request

## Structure

`CreateProductServiceRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productServiceName` | `string` | Required | - |

## Example (as JSON)

```json
{
  "productServiceName": "Natural Gas"
}
```

