
# Arr of Bill

## Structure

`ArrOfBill`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reportingAssetNameId` | `string` | Required | - |
| `utility` | `string` | Required | - |
| `billStartDate` | `string` | Required | - |
| `billEndDate` | `string` | Required | - |
| `billLink` | `string` | Required | - |
| `billName` | `string` | Required | - |
| `billInfo` | [`BillInfo[]`](../../doc/models/bill-info.md) | Required | - |
| `fiAssetId` | `string` | Required | - |
| `billAmount` | `number` | Required | - |
| `currency` | `string` | Required | - |

## Example (as JSON)

```json
{
  "reportingAssetNameId": "62662df11c119c2164badd10",
  "utility": "63ff1075e84c9f1c0cf7df56",
  "billStartDate": "1677609000",
  "billEndDate": "1680114600",
  "billLink": "uploads/ElectricBills.v2-1680439820580.csv",
  "billName": "ElectricBills",
  "billInfo": [
    {
      "productionUnitId": "63da9f3e535c66a30db7dda8",
      "billTotal": "454545",
      "productId": "63da524c64b6d636b88e9724",
      "accountNumber": 800863859
    }
  ],
  "fiAssetId": "080E329276C3D1FF06A344AEB0B15129",
  "billAmount": 10,
  "currency": "USD"
}
```

