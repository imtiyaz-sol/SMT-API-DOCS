
# Get All Reporting Asset FI Assets Request

## Structure

`GetAllReportingAssetFIAssetsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `configurationIds` | `string[]` | Required | - |
| `reportingAssetIds` | `string[]` | Required | - |

## Example (as JSON)

```json
{
  "configurationIds": [],
  "reportingAssetIds": []
}
```

