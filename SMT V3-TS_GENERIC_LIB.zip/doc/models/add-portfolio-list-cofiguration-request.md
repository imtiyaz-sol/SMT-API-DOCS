
# Add Portfolio List Cofiguration Request

## Structure

`AddPortfolioListCofigurationRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `configurationName` | `string` | Required | - |
| `arrAssetCategories` | `string[]` | Required | - |
| `arrAssetTypes` | `string[]` | Required | - |
| `arrSubAssetTypes` | `string[]` | Required | - |
| `arrAssetNames` | `string[]` | Required | - |

## Example (as JSON)

```json
{
  "configurationName": "Live data",
  "arrAssetCategories": [
    "6218a642dc5e3735ec198bc7"
  ],
  "arrAssetTypes": [
    "6218a649dc5e3735ec198c8d"
  ],
  "arrSubAssetTypes": [
    "6218a66ddc5e3735ec198ddb"
  ],
  "arrAssetNames": [
    "6218aa740c8a5f3f5ccbe844",
    "621cb3584de2263358dcc484"
  ]
}
```

