
# Arr of Vendor

## Structure

`ArrOfVendor`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vendorId` | `string` | Required | - |
| `productId` | `string` | Required | - |
| `accountId` | `string` | Required | - |
| `currency` | `string` | Required | - |

## Example (as JSON)

```json
{
  "vendorId": "6400ab53a4acadb06a1e3bc6",
  "productId": "63da524c64b6d636b88e9724",
  "accountId": "1234",
  "currency": "USD"
}
```

