
# Generate Mock Token Request

## Structure

`GenerateMockTokenRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userId` | `string` | Required | - |
| `role` | `string` | Required | - |

## Example (as JSON)

```json
{
  "userId": "8CB9348B055D25607AD45674CBF20A12",
  "role": "BCT Admin"
}
```

