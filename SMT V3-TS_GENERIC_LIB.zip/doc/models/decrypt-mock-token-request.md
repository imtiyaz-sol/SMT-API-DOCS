
# Decrypt Mock Token Request

## Structure

`DecryptMockTokenRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Required | - |

## Example (as JSON)

```json
{
  "token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIzQ0U1RThEQ0FGRENBMkFGNzU1OURBN0E4MDI3QjQ5NiIsInJvbGUiOiJEVCBNYW5hZ2VyL093bmVyIiwiY3JlYXRlZCI6IjE2ODI0OTkwNDYiLCJpYXQiOjE2ODI0OTkwNDd9.gfiXQWJya7wsppfyWLZVFthPimrk7YKXyMlcWkx7mOEkyq4WcxlWpmzf2BVbZPAyZjNC-aa2Q12Mv5_4XAVtrU_cyIyHz8wNGrrXYKDmydh1NmcPo5yV8GL_stkTcn5HM3TOAgGBtEGOfcJB1LNr5qTdzjlr3uMd0bgSS0vnJ2CRwleOmtMH6J00SUNDjDXR6348yJvwRmHr2qLn3dqs3cwgbtom_ruQQNDgJ47yE35aDSNfogu2v7kJi2JZVLkZy3-mUnlLlf_n5NhC6E3I3yZCUhqIj0ewfR88MI_1ojxo_uscMwjJwqTYtXAu95WV3VRP6D48oreDluPib6lBxw"
}
```

