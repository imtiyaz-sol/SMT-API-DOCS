
# Update Asset Category Status Request

## Structure

`UpdateAssetCategoryStatusRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string` | Required | - |
| `assetCategoryId` | `string` | Required | - |

## Example (as JSON)

```json
{
  "status": "N",
  "assetCategoryId": "6218a642dc5e3735ec198bc5"
}
```

