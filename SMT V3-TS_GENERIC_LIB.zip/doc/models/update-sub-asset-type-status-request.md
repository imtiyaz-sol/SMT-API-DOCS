
# Update Sub Asset Type Status Request

## Structure

`UpdateSubAssetTypeStatusRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string` | Required | - |
| `subAssetTypesId` | `string` | Required | - |

## Example (as JSON)

```json
{
  "status": "N",
  "subAssetTypesId": "6218a66ddc5e3735ec198e0f"
}
```

