
# Product Services List Request

## Structure

`ProductServicesListRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productService` | `string[]` | Required | - |

## Example (as JSON)

```json
{
  "productService": [
    "63da524c64b6d636b88e9724"
  ]
}
```

