
# Update Iot Manufacturer Request

## Structure

`UpdateIotManufacturerRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `manufacturerName` | `string` | Required | - |
| `address` | `string` | Required | - |
| `region` | `string` | Required | - |
| `country` | `string` | Required | - |
| `postalCode` | `string` | Required | - |
| `vendorCode` | `string` | Required | - |
| `accountContact` | [`AccountContact`](../../doc/models/account-contact.md) | Required | - |
| `supportContact` | [`SupportContact`](../../doc/models/support-contact.md) | Required | - |
| `docs` | [`Docs`](../../doc/models/docs.md) | Required | - |

## Example (as JSON)

```json
{
  "manufacturerName": "vvk",
  "address": "",
  "region": "",
  "country": "",
  "postalCode": "",
  "vendorCode": "",
  "accountContact": {
    "name": "Test",
    "email": "",
    "phone": ""
  },
  "supportContact": {
    "name": "",
    "email": "",
    "phone": ""
  },
  "docs": {
    "apiDoc": "uploads/dummy-1682064978386.pdf",
    "apiLink": "https://www.test.com",
    "legalDoc": "uploads/dummy-1682064985447.pdf"
  }
}
```

