
# Update Linking Request

## Structure

`UpdateLinkingRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `updateSolulabId` | `string` | Required | - |
| `fiAssetId` | `string` | Required | - |
| `solulabAssetId` | `string` | Required | - |

## Example (as JSON)

```json
{
  "updateSolulabId": "6218aa740c8a5f3f5ccbe844",
  "fiAssetId": "2A649C16B81FAC7289C04680CF3AF66A",
  "solulabAssetId": "62662df11c119c2164badd1a"
}
```

