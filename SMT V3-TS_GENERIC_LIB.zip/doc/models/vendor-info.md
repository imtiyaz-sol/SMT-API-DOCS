
# Vendor Info

## Structure

`VendorInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `manufacturerName` | `string` | Required | - |
| `state` | `string` | Required | - |

## Example (as JSON)

```json
{
  "manufacturerName": "Bermuda Electric Light Company",
  "state": "Hamilton"
}
```

