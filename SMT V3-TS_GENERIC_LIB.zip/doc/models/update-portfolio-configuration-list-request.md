
# Update Portfolio Configuration List Request

## Structure

`UpdatePortfolioConfigurationListRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `portfolioId` | `string` | Required | - |
| `portfolioInfo` | [`PortfolioInfo`](../../doc/models/portfolio-info.md) | Required | - |
| `portfolioConfigurationInfo` | [`PortfolioConfigurationInfo`](../../doc/models/portfolio-configuration-info.md) | Required | - |

## Example (as JSON)

```json
{
  "portfolioId": "CF352E3127BD34ABECC29187F7CF8F67",
  "portfolioInfo": {
    "isChanges": true,
    "portfolioName": "test update 123"
  },
  "portfolioConfigurationInfo": {
    "isChanges": true,
    "arrOfAssetInfo": [
      {
        "configurationId": "64034a413045cc3a80156c7c",
        "action": "DELETE",
        "assetId": "assetId4"
      },
      {
        "action": "CREATE",
        "assetId": "45CF4F54D3219242EDE4C6F721E6DCA0",
        "configurationId": "configurationId8"
      }
    ]
  }
}
```

