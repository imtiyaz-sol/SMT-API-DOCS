# Portfoliolist

```ts
const portfoliolistController = new PortfoliolistController(client);
```

## Class Name

`PortfoliolistController`

## Methods

* [Add Portfolio List Cofiguration](../../doc/controllers/portfoliolist.md#add-portfolio-list-cofiguration)
* [Get All Portfolio Configuration List](../../doc/controllers/portfoliolist.md#get-all-portfolio-configuration-list)
* [Create Portfolio Configuration List](../../doc/controllers/portfoliolist.md#create-portfolio-configuration-list)
* [Delete Portfolio Configuration List](../../doc/controllers/portfoliolist.md#delete-portfolio-configuration-list)
* [Update Portfolio Configuration List](../../doc/controllers/portfoliolist.md#update-portfolio-configuration-list)
* [Portfolio Configuration Info](../../doc/controllers/portfoliolist.md#portfolio-configuration-info)
* [Portfolio Configuration](../../doc/controllers/portfoliolist.md#portfolio-configuration)


# Add Portfolio List Cofiguration

```ts
async addPortfolioListCofiguration(
  authorization: string,
  body: AddPortfolioListCofigurationRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`AddPortfolioListCofigurationRequest`](../../doc/models/add-portfolio-list-cofiguration-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3MzcyMDcyIiwiaWF0IjoxNjY3MzcyMDcyfQ.iHY0nrG1UV0AnIvTReaBozD66K4BISoJFXPk8hiyde5xpUJPGJlsm5TLRLjGGm2wr0N_PyLQHl5JLyF5PCC-DUA2Is8sFZ59GJ-OYlLpajTi6uGCkeqJ2JZQ3O1NsmjXNgsg-pqkl19zNc_fvaODuu5nFRz9UxeJW3pozCW0X1OJnsodXWmqfRHmZVN104NCqIgIrZ93ua5hSyF4Mt5JMD7Am2Jt759VGynp6mg0pYbYyJB4S_J0TZu93FdLC5BiJW8rs6BPEL2YkXB52cNHQsqZvx6jDayMrHBglJmAoNHGLMqNFx5M5vQQE9Vw51deKYbKUNan9UQUWTgHMGpRBg';

const body: AddPortfolioListCofigurationRequest = {
  configurationName: 'Live data',
  arrAssetCategories: [
    '6218a642dc5e3735ec198bc7'
  ],
  arrAssetTypes: [
    '6218a649dc5e3735ec198c8d'
  ],
  arrSubAssetTypes: [
    '6218a66ddc5e3735ec198ddb'
  ],
  arrAssetNames: [
    '6218aa740c8a5f3f5ccbe844',
    '621cb3584de2263358dcc484'
  ],
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await portfolioListController.addPortfolioListCofiguration(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Get All Portfolio Configuration List

```ts
async getAllPortfolioConfigurationList(
  userId: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userId` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const userId = '8CB9348B055D25607AD45674CBF20A12';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJCMjFEODhDMzJBNDM2QUJGMjYyNjQ2RTk4NkMyQTJGRCIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3ODE5MDk5NSIsImlhdCI6MTY3ODE5MDk5NX0.CgBfAADn1fHRQ4kLd8ML1sF3NO6C4QOGGE4Bpu6MkuZGDUwHwCEYt_EwEKeKYCxQBsSbDRylirFBO8TfppVlu0srBD0ziAnrNtBNFnelBkDrcrt_Lkxj924qLjnhu7xlmzuf84A2LZ5RbIpyquLV8EAD4bw40ySVLpFLwlTmLj8VTAGiYUNqvDHxNi6KR09i4iu0-QBeMCtDfiK1JQqx0NYFW6_ixe1TL0QnUK-7orqp3sk7WotFPaICUj2fbOITbKfREurEBbc9OZBHEX2rkEevAzqT42WOfTk1DE22RDk6nWqx4TnXkYTECmN51Weok3d2ZtNK7ngshdGm4_1LHA';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await portfolioListController.getAllPortfolioConfigurationList(
  userId,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Create Portfolio Configuration List

```ts
async createPortfolioConfigurationList(
  authorization: string,
  body: CreatePortfolioConfigurationListRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`CreatePortfolioConfigurationListRequest`](../../doc/models/create-portfolio-configuration-list-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3ODA0MDIwIiwiaWF0IjoxNjY3ODA0MDIwfQ.lYBiy1NAUcirNNrN2fk7RBVlqiMWOwqYHa3ZcnvmCpwdq_pSzZendR6l47SmF81oKmg0TQcMQm9hzZmZu-rvBsfLJ5iDJznUlvcbvJLwtnLl_jMK5zKCrrFdybnvVvR46R6C24OSDRslnrQoj8SxW2qwIDdwN_6tUmRoJD2GAsV4KIGy-w_hcjdzWXnXmXoK-4LIo-NzDJU4YKGQGw6lemaLescPiamBkXZ4G3K1zUjmlCD17JM2a_yoYwN6OUDYC6ZWN8ewvKwf4JasU92OUt2yOfyJ67eLwfBc8_YWCNmCWgQdSqs-dzO5J2nad9OSPrtyaOhU4C37p4JzFpwsHg';

const body: CreatePortfolioConfigurationListRequest = {
  userId: '8CB9348B055D25607AD45674CBF20A12',
  portfolioName: 'Test ID 1',
  arrofAssetId: [
    '080E329276C3D1FF06A344AEB0B15129',
    '213D976EFBA2697E095CE58145F8F4AE',
    'C3354D58AA67E6C1CF29D6FB43EC177F'
  ],
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await portfolioListController.createPortfolioConfigurationList(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Delete Portfolio Configuration List

```ts
async deletePortfolioConfigurationList(
  portfolioId: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `portfolioId` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const portfolioId = '030EE45F2A0E5DA3466F719B493DCA1D';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3Nzg2MDMzNiIsImlhdCI6MTY3Nzg2MDMzNn0.HN49eLWvFj9MOaiSrFoQ8yA-qkubxJEPOtJd4C4bN-w1MhiUkZnibK3Rtq-OGlvPZxfAS8cMb-sSOQdTF8HDaqlyzOdwkoG2m0mRNUkeNBySQLn6IeuSKVU1LVqRKF1BPjQ0rIvQferClRnPBOM963P9PFTv56cIcsp_FmkbUv-feiNuJPsDLT7mYVMUHTgXqZG3cycDwQKhZX8S4dGA2nFVyLKZVjVYmDtVww7njKcO6-vlmTRlo7ZhGmnMYJV_y-Xj9YGih4u6WN6g5_73-xfozEa5CfXJUn7v2kIzqKoumQzcI5uSlAx-bm_nWGFsCJjKvyUQBkJM1hvzm3U3gw';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await portfolioListController.deletePortfolioConfigurationList(
  portfolioId,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Update Portfolio Configuration List

```ts
async updatePortfolioConfigurationList(
  authorization: string,
  body: UpdatePortfolioConfigurationListRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`UpdatePortfolioConfigurationListRequest`](../../doc/models/update-portfolio-configuration-list-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3Nzg2MDMzNiIsImlhdCI6MTY3Nzg2MDMzNn0.HN49eLWvFj9MOaiSrFoQ8yA-qkubxJEPOtJd4C4bN-w1MhiUkZnibK3Rtq-OGlvPZxfAS8cMb-sSOQdTF8HDaqlyzOdwkoG2m0mRNUkeNBySQLn6IeuSKVU1LVqRKF1BPjQ0rIvQferClRnPBOM963P9PFTv56cIcsp_FmkbUv-feiNuJPsDLT7mYVMUHTgXqZG3cycDwQKhZX8S4dGA2nFVyLKZVjVYmDtVww7njKcO6-vlmTRlo7ZhGmnMYJV_y-Xj9YGih4u6WN6g5_73-xfozEa5CfXJUn7v2kIzqKoumQzcI5uSlAx-bm_nWGFsCJjKvyUQBkJM1hvzm3U3gw';

const body: UpdatePortfolioConfigurationListRequest = {
  portfolioId: 'CF352E3127BD34ABECC29187F7CF8F67',
  portfolioInfo: {
    isChanges: true,
    portfolioName: 'test update 123',
  },
  portfolioConfigurationInfo: {
    isChanges: true,
    arrOfAssetInfo: [
      {
        action: 'DELETE',
        configurationId: '64034a413045cc3a80156c7c',
      },
      {
        action: 'CREATE',
        assetId: '45CF4F54D3219242EDE4C6F721E6DCA0',
      }
    ],
  },
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await portfolioListController.updatePortfolioConfigurationList(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Portfolio Configuration Info

```ts
async portfolioConfigurationInfo(
  portfolioId: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `portfolioId` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const portfolioId = 'CF352E3127BD34ABECC29187F7CF8F67';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3Nzg2MDMzNiIsImlhdCI6MTY3Nzg2MDMzNn0.HN49eLWvFj9MOaiSrFoQ8yA-qkubxJEPOtJd4C4bN-w1MhiUkZnibK3Rtq-OGlvPZxfAS8cMb-sSOQdTF8HDaqlyzOdwkoG2m0mRNUkeNBySQLn6IeuSKVU1LVqRKF1BPjQ0rIvQferClRnPBOM963P9PFTv56cIcsp_FmkbUv-feiNuJPsDLT7mYVMUHTgXqZG3cycDwQKhZX8S4dGA2nFVyLKZVjVYmDtVww7njKcO6-vlmTRlo7ZhGmnMYJV_y-Xj9YGih4u6WN6g5_73-xfozEa5CfXJUn7v2kIzqKoumQzcI5uSlAx-bm_nWGFsCJjKvyUQBkJM1hvzm3U3gw';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await portfolioListController.portfolioConfigurationInfo(
  portfolioId,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Portfolio Configuration

```ts
async portfolioConfiguration(
  configurationId: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `configurationId` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const configurationId = 'configurationId8';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3ODE3MDg0NSIsImlhdCI6MTY3ODE3MDg0NX0.bIOAeGwJVxTinlxl_NtMlQrlEYhI7EN_witAfuhNwoWnE5wnBngSyjfou5se2trDQVdGGncPoMQxfeYnoHC2vcuHS4U6v7B4qQkf9GSH4UvemX0CARDGKXxuiwPMzCvGS0eATonM7CP9CptgnA92khoVKRP7DZupeLN5aOOQ5FZv-PTrYJMuZ5BcHpmLClr953ta4feWmoyLkq4bknUbCJSIJs6UNqGxj66DpsY5ZdVKR46lO29a5QREYPXWGLWDaQffEaJI-UDRYzxwwh5l6JqJzo48ADB7vnGItXc1NxB84Kcamq-xBT9K3LwzUDdVMgtnuQEV7_VQk4p7n-Hymw';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await portfolioListController.portfolioConfiguration(
  configurationId,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

