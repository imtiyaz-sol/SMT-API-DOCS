# Assetinformation

```ts
const assetinformationController = new AssetinformationController(client);
```

## Class Name

`AssetinformationController`

## Methods

* [Asset Performance](../../doc/controllers/assetinformation.md#asset-performance)
* [Get All Reporting Asset](../../doc/controllers/assetinformation.md#get-all-reporting-asset)
* [Get All Reporting Asset FI Assets](../../doc/controllers/assetinformation.md#get-all-reporting-asset-fi-assets)
* [Get Reporting Asset Information](../../doc/controllers/assetinformation.md#get-reporting-asset-information)
* [Get Reporting Asset Information Fi Asset](../../doc/controllers/assetinformation.md#get-reporting-asset-information-fi-asset)
* [Update Fi Asset Information](../../doc/controllers/assetinformation.md#update-fi-asset-information)
* [Search Reporting Asset](../../doc/controllers/assetinformation.md#search-reporting-asset)
* [Search Fi Asset](../../doc/controllers/assetinformation.md#search-fi-asset)
* [Link Fi Assets to Solulab Assets](../../doc/controllers/assetinformation.md#link-fi-assets-to-solulab-assets)
* [Unlink Fi Asset From Solulab Asset](../../doc/controllers/assetinformation.md#unlink-fi-asset-from-solulab-asset)
* [Update Linking](../../doc/controllers/assetinformation.md#update-linking)


# Asset Performance

```ts
async assetPerformance(
  authorization: string,
  body: AssetPerformanceRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`AssetPerformanceRequest`](../../doc/models/asset-performance-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJENTVGQkYwQzY2MjRFQzM1RDAwNkYxMEZFREEwOEYwRCIsInJvbGUiOiJEVCBTbWFydCBNZXRlciAvIFZlbmRvciBSb2xlIiwidHlwZSI6IkRFRkFVTFQiLCJjcmVhdGVkIjoiMTY4MTM5MzkzMiIsImlhdCI6MTY4MTM5MzkzMn0.GDghimkfryxAfOKPxz1fdc4Po7quBY0C9w6ggATqQeBkOkUvbUGexIt3oxFZCvInnUsndTJINN-fb8bwokcwiWwPWlkZmd2v-ADZymMOzE6hMQu2f7-AlZOordV-J8N9o3_CXhNjgjDoDP5sTMrn7XoJn9XpZYYeMoDahNXQ9ly_UjfLEeExCLcnY7WefuE6WWZcECHsvgWRUIzrXeZJvnrDZ1x79zjAZV6hdeQPuwtUY-9KVPzj639Z-Ds72j_KdFd-7MK3HlyK0YJAzXjM4ZWt5cr9FDDns74B3ewqCylyCJw3UMpDPukR1BKOPVSAH_WGYG_QrcSuQ4x-pbaZuA';

const body: AssetPerformanceRequest = {
  fiAssetId: '1C67ECEDB2969E52E03F6472A60A577C',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await assetInformationController.assetPerformance(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Get All Reporting Asset

```ts
async getAllReportingAsset(
  authorization: string,
  body: GetAllReportingAssetRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`GetAllReportingAssetRequest`](../../doc/models/get-all-reporting-asset-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY2MTYwMTc0IiwiaWF0IjoxNjY2MTYwMTc0fQ.MWsgeUFSSNPsAQ34F2LKpFqzn2yyqJ2E3LbWvyeDB9pB32O4Pevfm9nde0qYpmx93CZA4YNfX8znQDi0lloy7jwlnB3Xz0V_GIWr6kKpSslLmQUOmXyVKyhjrUcFETM9DtGPU50q_nStbp8YjTRYGAw3pyi1hGOZ8sNv5-e_xFBMXMyqVtEUQWGbwHZoGfROzXeAolqhf4dyIO9MG8Vcsr8lCab3tK8U0IveAd-7Ygj8gyXpNLuO1ZnbX7R9GAtU7Z-vp6PrdVm8SagRKC2yC0JDt9j3FdTtUU_Goyx1FJdTfU1UbYSk8LHO6OwvcBOtkbnQhAkP0Ld8voJ3TVcRpw';

const body: GetAllReportingAssetRequest = {
  configurationIds: [
    '63d25c05e27fab3c669c5718'
  ],
  reportingAssetIds: [
    '6218aa740c8a5f3f5ccbe844',
    '62662df11c119c2164badd65',
    '62662df11c119c2164badd1e'
  ],
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await assetInformationController.getAllReportingAsset(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Get All Reporting Asset FI Assets

```ts
async getAllReportingAssetFIAssets(
  authorization: string,
  body: GetAllReportingAssetFIAssetsRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`GetAllReportingAssetFIAssetsRequest`](../../doc/models/get-all-reporting-asset-fi-assets-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY4MjU3NjIxMyIsImlhdCI6MTY4MjU3NjIxM30.kbClbebIYWKF19ewbRllofdB8u-pUVhtEJhcHiorwEApy5PkBMldBEc6iZ_aCoVcGEEzHC-0RN3CtogW5Opd7O7e8IlOcHLFy_H7EY-7cPYHWfgdSZe_PJ9YU3NlzHvk_9IIlj9axyB-T42keYGpQbsio_sh3wZkkn4SBnDXHV7VPvBfkUJXhURQRvD7EGiTDKUWt14AdV6k3GN58sDijcTz3dQfbkjyp6FhP44lYDBLygShIdnarVvzD8i0oLAgWFDyJotz0uWqXsepi3B-9mj-XbHYvPnuQDO4UK_GBnw0IgwNZ-EwEHvm2dG_5rWgv25PuOTGYROIhFqfOqhY9w';

const body: GetAllReportingAssetFIAssetsRequest = {
  configurationIds: [],
  reportingAssetIds: [],
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await assetInformationController.getAllReportingAssetFIAssets(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Get Reporting Asset Information

```ts
async getReportingAssetInformation(
  authorization: string,
  body: GetReportingAssetInformationRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`GetReportingAssetInformationRequest`](../../doc/models/get-reporting-asset-information-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY2MTYzMTEyIiwiaWF0IjoxNjY2MTYzMTEyfQ.T0zCiHSxggWyYvfivWqyeyMuVC4UySdZXwzeTntm8QuLeo8an1S4EzuS4fCrNJSz20__qvWb77IDGf2fFclMTlvIyRqtWet3brMSdS1K7X8BUGrNuovZ77zgdagUP_BknACWbHF_wVINpHVJKg_2YeTl7GiFtFMbzwsujKM1rPzaEtMlD1X28KNi7kocE7jDZi5vxLV-4or1XynEo-ItO1F4_gAq6CYAusIxRqJsepr-Hkx42mmzrGrK6cH89dZpxgt8GAJIphusE5eUHfBKinnmKpPv2Hgrfpo7AMRsweNX3X9rgFao9RY_0B7JFsYmhe_AZCsyri5DlqEVprJUgA';

const body: GetReportingAssetInformationRequest = {
  id: '6218aa740c8a5f3f5ccbe844',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await assetInformationController.getReportingAssetInformation(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Get Reporting Asset Information Fi Asset

```ts
async getReportingAssetInformationFiAsset(
  authorization: string,
  body: GetReportingAssetInformationFiAssetRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`GetReportingAssetInformationFiAssetRequest`](../../doc/models/get-reporting-asset-information-fi-asset-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY2MTYzMTEyIiwiaWF0IjoxNjY2MTYzMTEyfQ.T0zCiHSxggWyYvfivWqyeyMuVC4UySdZXwzeTntm8QuLeo8an1S4EzuS4fCrNJSz20__qvWb77IDGf2fFclMTlvIyRqtWet3brMSdS1K7X8BUGrNuovZ77zgdagUP_BknACWbHF_wVINpHVJKg_2YeTl7GiFtFMbzwsujKM1rPzaEtMlD1X28KNi7kocE7jDZi5vxLV-4or1XynEo-ItO1F4_gAq6CYAusIxRqJsepr-Hkx42mmzrGrK6cH89dZpxgt8GAJIphusE5eUHfBKinnmKpPv2Hgrfpo7AMRsweNX3X9rgFao9RY_0B7JFsYmhe_AZCsyri5DlqEVprJUgA';

const body: GetReportingAssetInformationFiAssetRequest = {
  reportingAssetNameId: '62662df11c119c2164badd10',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await assetInformationController.getReportingAssetInformationFiAsset(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Update Fi Asset Information

```ts
async updateFiAssetInformation(
  authorization: string,
  body: UpdateFiAssetInformationRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`UpdateFiAssetInformationRequest`](../../doc/models/update-fi-asset-information-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY2MTYzMTEyIiwiaWF0IjoxNjY2MTYzMTEyfQ.T0zCiHSxggWyYvfivWqyeyMuVC4UySdZXwzeTntm8QuLeo8an1S4EzuS4fCrNJSz20__qvWb77IDGf2fFclMTlvIyRqtWet3brMSdS1K7X8BUGrNuovZ77zgdagUP_BknACWbHF_wVINpHVJKg_2YeTl7GiFtFMbzwsujKM1rPzaEtMlD1X28KNi7kocE7jDZi5vxLV-4or1XynEo-ItO1F4_gAq6CYAusIxRqJsepr-Hkx42mmzrGrK6cH89dZpxgt8GAJIphusE5eUHfBKinnmKpPv2Hgrfpo7AMRsweNX3X9rgFao9RY_0B7JFsYmhe_AZCsyri5DlqEVprJUgA';

const body: UpdateFiAssetInformationRequest = {
  fiAssetId: '',
  fiAssetData: {  },
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await assetInformationController.updateFiAssetInformation(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Search Reporting Asset

```ts
async searchReportingAsset(
  authorization: string,
  body: SearchReportingAssetRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`SearchReportingAssetRequest`](../../doc/models/search-reporting-asset-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY2MTYzMTEyIiwiaWF0IjoxNjY2MTYzMTEyfQ.T0zCiHSxggWyYvfivWqyeyMuVC4UySdZXwzeTntm8QuLeo8an1S4EzuS4fCrNJSz20__qvWb77IDGf2fFclMTlvIyRqtWet3brMSdS1K7X8BUGrNuovZ77zgdagUP_BknACWbHF_wVINpHVJKg_2YeTl7GiFtFMbzwsujKM1rPzaEtMlD1X28KNi7kocE7jDZi5vxLV-4or1XynEo-ItO1F4_gAq6CYAusIxRqJsepr-Hkx42mmzrGrK6cH89dZpxgt8GAJIphusE5eUHfBKinnmKpPv2Hgrfpo7AMRsweNX3X9rgFao9RY_0B7JFsYmhe_AZCsyri5DlqEVprJUgA';

const body: SearchReportingAssetRequest = {
  term: 'first',
  limit: 5,
  skip: 0,
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await assetInformationController.searchReportingAsset(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Search Fi Asset

```ts
async searchFiAsset(
  authorization: string,
  body: SearchFiAssetRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`SearchFiAssetRequest`](../../doc/models/search-fi-asset-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY2MTYzMTEyIiwiaWF0IjoxNjY2MTYzMTEyfQ.T0zCiHSxggWyYvfivWqyeyMuVC4UySdZXwzeTntm8QuLeo8an1S4EzuS4fCrNJSz20__qvWb77IDGf2fFclMTlvIyRqtWet3brMSdS1K7X8BUGrNuovZ77zgdagUP_BknACWbHF_wVINpHVJKg_2YeTl7GiFtFMbzwsujKM1rPzaEtMlD1X28KNi7kocE7jDZi5vxLV-4or1XynEo-ItO1F4_gAq6CYAusIxRqJsepr-Hkx42mmzrGrK6cH89dZpxgt8GAJIphusE5eUHfBKinnmKpPv2Hgrfpo7AMRsweNX3X9rgFao9RY_0B7JFsYmhe_AZCsyri5DlqEVprJUgA';

const body: SearchFiAssetRequest = {
  term: 'first',
  limit: 5,
  skip: 0,
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await assetInformationController.searchFiAsset(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Link Fi Assets to Solulab Assets

```ts
async linkFiAssetsToSolulabAssets(
  authorization: string,
  body: LinkFiAssetsToSolulabAssetsRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`LinkFiAssetsToSolulabAssetsRequest`](../../doc/models/link-fi-assets-to-solulab-assets-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY2MTYzMTEyIiwiaWF0IjoxNjY2MTYzMTEyfQ.T0zCiHSxggWyYvfivWqyeyMuVC4UySdZXwzeTntm8QuLeo8an1S4EzuS4fCrNJSz20__qvWb77IDGf2fFclMTlvIyRqtWet3brMSdS1K7X8BUGrNuovZ77zgdagUP_BknACWbHF_wVINpHVJKg_2YeTl7GiFtFMbzwsujKM1rPzaEtMlD1X28KNi7kocE7jDZi5vxLV-4or1XynEo-ItO1F4_gAq6CYAusIxRqJsepr-Hkx42mmzrGrK6cH89dZpxgt8GAJIphusE5eUHfBKinnmKpPv2Hgrfpo7AMRsweNX3X9rgFao9RY_0B7JFsYmhe_AZCsyri5DlqEVprJUgA';

const body: LinkFiAssetsToSolulabAssetsRequest = {
  fiAssetId: '98631443238BF8B758192B346D1CD507',
  solulabAssetId: '621cb3584de2263358dcc484',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await assetInformationController.linkFiAssetsToSolulabAssets(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Unlink Fi Asset From Solulab Asset

```ts
async unlinkFiAssetFromSolulabAsset(
  authorization: string,
  body: UnlinkFiAssetFromSolulabAssetRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`UnlinkFiAssetFromSolulabAssetRequest`](../../doc/models/unlink-fi-asset-from-solulab-asset-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY2MTYzMTEyIiwiaWF0IjoxNjY2MTYzMTEyfQ.T0zCiHSxggWyYvfivWqyeyMuVC4UySdZXwzeTntm8QuLeo8an1S4EzuS4fCrNJSz20__qvWb77IDGf2fFclMTlvIyRqtWet3brMSdS1K7X8BUGrNuovZ77zgdagUP_BknACWbHF_wVINpHVJKg_2YeTl7GiFtFMbzwsujKM1rPzaEtMlD1X28KNi7kocE7jDZi5vxLV-4or1XynEo-ItO1F4_gAq6CYAusIxRqJsepr-Hkx42mmzrGrK6cH89dZpxgt8GAJIphusE5eUHfBKinnmKpPv2Hgrfpo7AMRsweNX3X9rgFao9RY_0B7JFsYmhe_AZCsyri5DlqEVprJUgA';

const body: UnlinkFiAssetFromSolulabAssetRequest = {
  solulabAssetId: '6215dcbf321bae24f4a1bb75',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await assetInformationController.unlinkFiAssetFromSolulabAsset(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Update Linking

```ts
async updateLinking(
  authorization: string,
  body: UpdateLinkingRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`UpdateLinkingRequest`](../../doc/models/update-linking-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY2MTYzMTEyIiwiaWF0IjoxNjY2MTYzMTEyfQ.T0zCiHSxggWyYvfivWqyeyMuVC4UySdZXwzeTntm8QuLeo8an1S4EzuS4fCrNJSz20__qvWb77IDGf2fFclMTlvIyRqtWet3brMSdS1K7X8BUGrNuovZ77zgdagUP_BknACWbHF_wVINpHVJKg_2YeTl7GiFtFMbzwsujKM1rPzaEtMlD1X28KNi7kocE7jDZi5vxLV-4or1XynEo-ItO1F4_gAq6CYAusIxRqJsepr-Hkx42mmzrGrK6cH89dZpxgt8GAJIphusE5eUHfBKinnmKpPv2Hgrfpo7AMRsweNX3X9rgFao9RY_0B7JFsYmhe_AZCsyri5DlqEVprJUgA';

const body: UpdateLinkingRequest = {
  updateSolulabId: '6218aa740c8a5f3f5ccbe844',
  fiAssetId: '2A649C16B81FAC7289C04680CF3AF66A',
  solulabAssetId: '62662df11c119c2164badd1a',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await assetInformationController.updateLinking(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

