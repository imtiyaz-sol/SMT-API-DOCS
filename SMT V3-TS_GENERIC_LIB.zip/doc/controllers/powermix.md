# Powermix

```ts
const powermixController = new PowermixController(client);
```

## Class Name

`PowermixController`


# Import Vendor and Power Mix Data

```ts
async importVendorAndPowerMixData(
  authorization: string,
  body: ImportVendorAndPowerMixDataRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`ImportVendorAndPowerMixDataRequest`](../../doc/models/import-vendor-and-power-mix-data-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NDQ1NzgwMCIsImlhdCI6MTY3NDQ1NzgwMH0.rKk2RhwWopIQOvQ4WXxmAUIrCuT3Xik19OBG7v3mo__d0QCXraQrWqwOX5gNftrDxX8BexMSN0kAshW6PdcgDGkiaFm-NL_-ImLr96kh4dsWcCPa7TYVf0-AcxbEqeY7QsYKkhahsezexAMlqOyTyDETUPapHlaETIakMCA6BwAhJpkh4ZAp9l-96m2a7KJcFy7wmrlcC1NtqVCe8w8l0-dtYnm0cYUGR_AQFgasYoWIFiOyw7vJ4V6yMg3HQShnVhegqlWfEf5OFUmb8NPmaUCh9oZkWb93L41NNzTBKGwReXBBJEOmR2OGExnk8LM0XC1w7n7rsPsrEH6j-ucbkg';

const body: ImportVendorAndPowerMixDataRequest = {
  vendorInfo: {
    manufacturerName: 'Bermuda Electric Light Company',
    state: 'Hamilton',
  },
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await powerMixController.importVendorAndPowerMixData(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

