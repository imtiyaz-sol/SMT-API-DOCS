# Tokenization

```ts
const tokenizationController = new TokenizationController(client);
```

## Class Name

`TokenizationController`

## Methods

* [Create Tokenization URL](../../doc/controllers/tokenization.md#create-tokenization-url)
* [Create Tokenization URL Copy](../../doc/controllers/tokenization.md#create-tokenization-url-copy)


# Create Tokenization URL

```ts
async createTokenizationURL(
  authorization: string,
  body: CreateTokenizationURLRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`CreateTokenizationURLRequest`](../../doc/models/create-tokenization-url-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3MzcyMDcyIiwiaWF0IjoxNjY3MzcyMDcyfQ.iHY0nrG1UV0AnIvTReaBozD66K4BISoJFXPk8hiyde5xpUJPGJlsm5TLRLjGGm2wr0N_PyLQHl5JLyF5PCC-DUA2Is8sFZ59GJ-OYlLpajTi6uGCkeqJ2JZQ3O1NsmjXNgsg-pqkl19zNc_fvaODuu5nFRz9UxeJW3pozCW0X1OJnsodXWmqfRHmZVN104NCqIgIrZ93ua5hSyF4Mt5JMD7Am2Jt759VGynp6mg0pYbYyJB4S_J0TZu93FdLC5BiJW8rs6BPEL2YkXB52cNHQsqZvx6jDayMrHBglJmAoNHGLMqNFx5M5vQQE9Vw51deKYbKUNan9UQUWTgHMGpRBg';

const body: CreateTokenizationURLRequest = {
  iFrameUrl: 'https://digital.bctriangle.com:447/iframecontent/meterListing?options=All&token=eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZXN0IjoidGhpcyBpcyB0ZXN0IGRhdGEiLCJjcmVhdGVkIjoiMTY0NzQ0MTA0NSIsImlhdCI6MTY0NzQ0MTA0NX0.OiLq2em6s9EDXze9XplDLeTtg6QzDbfELBpN4agqmCNUajuKLX-oMVr2ZtjB-jQewXVFvj56_B1m7iNRm3mhtbY9i579poAcuv0RGjs061eFFY6w_fTPXi-PhT-mRJXpVsH5-fXgYmGxrA3l-L0omO0J7XrCXIou58jgSaIo8svRzqJK7toW8FsLufDSZ_MghTANO0wNpN4iXedwIEgG3TmfltSEaqVlEWq13ddrFKIMkzhttoAWyOGTU68EXbQT7mvm2TxgLEXijstN19iP5lZJvuNtXlRVtu2O7dPM9Ro0qzEDgPMzxYditawTeDxc3vaodID2IMAFniASzWq3Zw',
  configurationIds: [
    '636258afeff65b05c85b43e4',
    '63a1f336df3fc13935624666'
  ],
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await tokenizationController.createTokenizationURL(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Create Tokenization URL Copy

```ts
async createTokenizationURLCopy(
  authorization: string,
  body: CreateTokenizationURLCopyRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`CreateTokenizationURLCopyRequest`](../../doc/models/create-tokenization-url-copy-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3MjgxMzExMCIsImlhdCI6MTY3MjgxMzExMH0.SI0hQ8ZofPy4a0KxzJ1W53RobfVJgOjtytkTbuZdGB9iLDGLjjNqUJyKOyLEi9WLekAVJzCtWVv9kXj4vEzI25NEcYmESiXxZUjn6Prtts6CM6t7qWQLsxprb2E1Dg17eio6mcfR7a8gmcvC_alobiD7a-__iz5QAbCb4kZcV2MW9GuAthV0OVjBQt5In2jUbnB2BWghZo3TUHwX-PkLLly0jEGKmkEmZf4JI0BmPzW9IpmsR2nmj9ljygLP0U03KGK3-0icBJxkYzxxsi5UByR__2D96cWhjQbNTFAhlJVsd4risg-f625dnVXy7cEEyOQ7dgIgd9h7D17EeX4SPA';

const body: CreateTokenizationURLCopyRequest = {
  arrAssetCategories: [],
  arrAssetTypes: [],
  arrSubAssetTypes: [],
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await tokenizationController.createTokenizationURLCopy(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

