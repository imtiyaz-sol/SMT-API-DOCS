# Dashboard

```ts
const dashboardController = new DashboardController(client);
```

## Class Name

`DashboardController`

## Methods

* [Dashboard API](../../doc/controllers/dashboard.md#dashboard-api)
* [Get All Asset Types](../../doc/controllers/dashboard.md#get-all-asset-types)
* [Get All Reporting Assets](../../doc/controllers/dashboard.md#get-all-reporting-assets)
* [Get All Reporting Assets Graph](../../doc/controllers/dashboard.md#get-all-reporting-assets-graph)


# Dashboard API

```ts
async dashboardAPI(
  authorization: string,
  body: DashboardAPIRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`DashboardAPIRequest`](../../doc/models/dashboard-api-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3ODM1MzYyMiIsImlhdCI6MTY3ODM1MzYyMn0.Q0rKGsrKxPASbArD-2ZcIajE_9j1IBPX1TR8tUmYErjrndynyfPjgdWbFqDoOIbigniCMdPLRaQHFs8c7VavFqITIlWtKycJT4r5OZ78_aE7MhOi-JeUsIKIPQzYcsMPqtvZcnk4NL3KaiA2-SGCjMrbUbvncMRuhEVzElWx-m6Q3cvH3uurKgcrPE4Su4HCuJt1Dy-wHJkPKVHq1ktQ2P87yAgFGIOZ2SHBTZcotHl_nwdZkeYrvRhdiY4OxDoXpjfT63ZpDS3PY7rLVMrl-7136Kyjlm4sMe_jwwoZgMaLx3oxKnqt8JBCnPQrRtA-z7yfUgpz0Degu5SjfE1nlw';

const body: DashboardAPIRequest = {
  configurationIds: [
    'B4682109C13EDDDD1CB19EFBF52D690D'
  ],
  reportingAssetIds: [],
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await dashboardController.dashboardAPI(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Get All Asset Types

```ts
async getAllAssetTypes(
  authorization: string,
  body: GetAllAssetTypesRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`GetAllAssetTypesRequest`](../../doc/models/get-all-asset-types-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3ODE3NTAyMyIsImlhdCI6MTY3ODE3NTAyM30.B8iKnIFq_sRf5tlXuZqeVlGcjkiZdIqA5rMKwaovKB0BPUQwr3fmBq0j9MYp6nrnpe5Gs5jERR11N7BvS96zNSD3HoZwJhJO5x8RjXKGy5KR-AdUlrQqGavORdtH_OqgI8v2GKIJnXfzlotauGUKKKY6K7fP_EybP3E69T8G2RQNJTnrNZXrf0y9gpe274G92A2L4Wv0z3J7MFjzhcerAa7s8OobxSShoUaq_U6KYv18l3b97ur8flOwjzvcXAARvCD_4iHuvAJbAmfPKqmBOqr3hwf-G_Jwni8rrASedVznj5_kHKSar2JfxIz-PkmZ23epOA-DDp6jBErZLJZviQ';

const body: GetAllAssetTypesRequest = {
  configurationIds: [
    '0A8DF46C22B8009EF2B32EB92D231C7E'
  ],
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await dashboardController.getAllAssetTypes(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Get All Reporting Assets

```ts
async getAllReportingAssets(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3OTkxOTUwNyIsImlhdCI6MTY3OTkxOTUwN30.khNLPOY3auwpfd5myCEXjA0cmmBnFFIYRGfWTo3foOMhg3gWe9aIMD2feXeGHQYy4pwKJl4RG2OFfv7cjSp4NzmWhwX9jUUZSImRQN5rdN6DAClFfusv7yrnkKrW2IR9aHxFAvr3p59Bw3OayyUJFOkOXyFypKZcaEljMsuKhTlVlR8oHrcGV260jh_Fv1Vg2ndjYoE4BiYA3DtVfyjWGeAxEzNuZQyOzH_sNBp-eLze3H74hpwjGZOTxDpZFSYwyZTRu2A72ULJEwx2x5ASn1Pp2-KcAd-lxymEBE2C9qIw5iQ__67Gk84TQx4OB9yCLYL2JZ7nBarJZqzCivbHuA';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await dashboardController.getAllReportingAssets(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Get All Reporting Assets Graph

```ts
async getAllReportingAssetsGraph(
  authorization: string,
  body: GetAllReportingAssetsGraphRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`GetAllReportingAssetsGraphRequest`](../../doc/models/get-all-reporting-assets-graph-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3ODE3MDg0NSIsImlhdCI6MTY3ODE3MDg0NX0.bIOAeGwJVxTinlxl_NtMlQrlEYhI7EN_witAfuhNwoWnE5wnBngSyjfou5se2trDQVdGGncPoMQxfeYnoHC2vcuHS4U6v7B4qQkf9GSH4UvemX0CARDGKXxuiwPMzCvGS0eATonM7CP9CptgnA92khoVKRP7DZupeLN5aOOQ5FZv-PTrYJMuZ5BcHpmLClr953ta4feWmoyLkq4bknUbCJSIJs6UNqGxj66DpsY5ZdVKR46lO29a5QREYPXWGLWDaQffEaJI-UDRYzxwwh5l6JqJzo48ADB7vnGItXc1NxB84Kcamq-xBT9K3LwzUDdVMgtnuQEV7_VQk4p7n-Hymw';

const body: GetAllReportingAssetsGraphRequest = {
  assetTypesId: '6218a64adc5e3735ec198cfd',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await dashboardController.getAllReportingAssetsGraph(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

