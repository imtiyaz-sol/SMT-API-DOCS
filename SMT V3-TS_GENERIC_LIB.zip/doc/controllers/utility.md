# Utility

```ts
const utilityController = new UtilityController(client);
```

## Class Name

`UtilityController`

## Methods

* [Utility Dashboard](../../doc/controllers/utility.md#utility-dashboard)
* [Utility Provider List](../../doc/controllers/utility.md#utility-provider-list)
* [Production Unit List](../../doc/controllers/utility.md#production-unit-list)
* [Reporitng Asset S File History](../../doc/controllers/utility.md#reporitng-asset-s-file-history)
* [Product Services List](../../doc/controllers/utility.md#product-services-list)
* [Utility Bills](../../doc/controllers/utility.md#utility-bills)
* [Set Vendor](../../doc/controllers/utility.md#set-vendor)


# Utility Dashboard

```ts
async utilityDashboard(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJBODg4RDE2MDFBNkI3MjU5MTBCQjQzQ0JBNUREQzhCNSIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY4MTIwNjk2MiIsImlhdCI6MTY4MTIwNjk2Mn0.BRAk38gfDAq0QHSIK6WfD2w1TcZeaS-CBaE93uOy-SjFNjOpJsgr5UmbibYKI6O0Q52L75x521lExzpIFGhyJG0t23dGvxb8PYuG4nWs72cJpMqe_MdQKo-xiI4KT6iVbQN-VWNPtFATAJeNy_k6pmcPD5g_HAq80-CAwEEowj0cay8RUQOWehiHfuT7Liggt-CXMSKYA4nSbPpob0lkNUoexuEWHWNQkIYn6ifvCKXnb053IvksCtEwJ-ZtV-jj6-hRgbnX5WRuB9QmQEgAumBnhqNVjkJAL3GpwZ2MV5UbTeF-rXdn-N980y_D961UaYvCD4Ohr_M8JYpjkv_GOw';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await utilityController.utilityDashboard(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Utility Provider List

```ts
async utilityProviderList(
  reportingAssetId: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reportingAssetId` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const reportingAssetId = '62662df11c119c2164badd10';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJGQzA3QTc3Q0NGNTlFODg4QzNCMDZDN0YwRDZDMTc3QiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NzIzNjc0OSIsImlhdCI6MTY3NzIzNjc0OX0.sQt0nrFDgfR91PzSTaeMfhTsdI43vg33xWca4UerIVoS8QNkT6A6BfzhILLpmIwGSS-yjdVimsob0LHvQ1msUcVm8XBace24vttWHgfGRHwxbAuJe1G2qk-drtaz8Kw0Iso_I_5ldbmGLMw4GVw8lR0oBDUeJbgc7TYWNUfOav4OL2U2udM7CXHXZk8RqWVbjaiaXcWyQfDHtP_9lgpFM2fSrVYK6LsRQtlNOc6qxtIurnWKCFqi1dWSHM23WAA75v5d90Sq-Oc5is1Q7L9jhmzxHgtcgOI_wXhM50z5Nq6ad0tuSArVclIUT5D7rlXOdg914apyO63-HlcsHRQJog';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await utilityController.utilityProviderList(
  reportingAssetId,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Production Unit List

```ts
async productionUnitList(
  vendorListId: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vendorListId` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const vendorListId = '63da526764b6d636b88e972e';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3ODA0MDIwIiwiaWF0IjoxNjY3ODA0MDIwfQ.lYBiy1NAUcirNNrN2fk7RBVlqiMWOwqYHa3ZcnvmCpwdq_pSzZendR6l47SmF81oKmg0TQcMQm9hzZmZu-rvBsfLJ5iDJznUlvcbvJLwtnLl_jMK5zKCrrFdybnvVvR46R6C24OSDRslnrQoj8SxW2qwIDdwN_6tUmRoJD2GAsV4KIGy-w_hcjdzWXnXmXoK-4LIo-NzDJU4YKGQGw6lemaLescPiamBkXZ4G3K1zUjmlCD17JM2a_yoYwN6OUDYC6ZWN8ewvKwf4JasU92OUt2yOfyJ67eLwfBc8_YWCNmCWgQdSqs-dzO5J2nad9OSPrtyaOhU4C37p4JzFpwsHg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await utilityController.productionUnitList(
  vendorListId,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Reporitng Asset S File History

```ts
async reporitngAssetSFileHistory(
  reportingAssetNameId: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reportingAssetNameId` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const reportingAssetNameId = '62662df11c119c2164badd0b';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3ODA0MDIwIiwiaWF0IjoxNjY3ODA0MDIwfQ.lYBiy1NAUcirNNrN2fk7RBVlqiMWOwqYHa3ZcnvmCpwdq_pSzZendR6l47SmF81oKmg0TQcMQm9hzZmZu-rvBsfLJ5iDJznUlvcbvJLwtnLl_jMK5zKCrrFdybnvVvR46R6C24OSDRslnrQoj8SxW2qwIDdwN_6tUmRoJD2GAsV4KIGy-w_hcjdzWXnXmXoK-4LIo-NzDJU4YKGQGw6lemaLescPiamBkXZ4G3K1zUjmlCD17JM2a_yoYwN6OUDYC6ZWN8ewvKwf4JasU92OUt2yOfyJ67eLwfBc8_YWCNmCWgQdSqs-dzO5J2nad9OSPrtyaOhU4C37p4JzFpwsHg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await utilityController.reporitngAssetSFileHistory(
  reportingAssetNameId,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Product Services List

```ts
async productServicesList(
  authorization: string,
  body: ProductServicesListRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`ProductServicesListRequest`](../../doc/models/product-services-list-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3ODA0MDIwIiwiaWF0IjoxNjY3ODA0MDIwfQ.lYBiy1NAUcirNNrN2fk7RBVlqiMWOwqYHa3ZcnvmCpwdq_pSzZendR6l47SmF81oKmg0TQcMQm9hzZmZu-rvBsfLJ5iDJznUlvcbvJLwtnLl_jMK5zKCrrFdybnvVvR46R6C24OSDRslnrQoj8SxW2qwIDdwN_6tUmRoJD2GAsV4KIGy-w_hcjdzWXnXmXoK-4LIo-NzDJU4YKGQGw6lemaLescPiamBkXZ4G3K1zUjmlCD17JM2a_yoYwN6OUDYC6ZWN8ewvKwf4JasU92OUt2yOfyJ67eLwfBc8_YWCNmCWgQdSqs-dzO5J2nad9OSPrtyaOhU4C37p4JzFpwsHg';

const body: ProductServicesListRequest = {
  productService: [
    '63da524c64b6d636b88e9724'
  ],
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await utilityController.productServicesList(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Utility Bills

```ts
async utilityBills(
  fiAssetId: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fiAssetId` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const fiAssetId = 'A4A29C28B27FE7254D57276728CFDCC9';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3ODA0MDIwIiwiaWF0IjoxNjY3ODA0MDIwfQ.lYBiy1NAUcirNNrN2fk7RBVlqiMWOwqYHa3ZcnvmCpwdq_pSzZendR6l47SmF81oKmg0TQcMQm9hzZmZu-rvBsfLJ5iDJznUlvcbvJLwtnLl_jMK5zKCrrFdybnvVvR46R6C24OSDRslnrQoj8SxW2qwIDdwN_6tUmRoJD2GAsV4KIGy-w_hcjdzWXnXmXoK-4LIo-NzDJU4YKGQGw6lemaLescPiamBkXZ4G3K1zUjmlCD17JM2a_yoYwN6OUDYC6ZWN8ewvKwf4JasU92OUt2yOfyJ67eLwfBc8_YWCNmCWgQdSqs-dzO5J2nad9OSPrtyaOhU4C37p4JzFpwsHg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await utilityController.utilityBills(
  fiAssetId,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Set Vendor

```ts
async setVendor(
  authorization: string,
  body: SetVendorRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`SetVendorRequest`](../../doc/models/set-vendor-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJGQzA3QTc3Q0NGNTlFODg4QzNCMDZDN0YwRDZDMTc3QiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NzIzNjc0OSIsImlhdCI6MTY3NzIzNjc0OX0.sQt0nrFDgfR91PzSTaeMfhTsdI43vg33xWca4UerIVoS8QNkT6A6BfzhILLpmIwGSS-yjdVimsob0LHvQ1msUcVm8XBace24vttWHgfGRHwxbAuJe1G2qk-drtaz8Kw0Iso_I_5ldbmGLMw4GVw8lR0oBDUeJbgc7TYWNUfOav4OL2U2udM7CXHXZk8RqWVbjaiaXcWyQfDHtP_9lgpFM2fSrVYK6LsRQtlNOc6qxtIurnWKCFqi1dWSHM23WAA75v5d90Sq-Oc5is1Q7L9jhmzxHgtcgOI_wXhM50z5Nq6ad0tuSArVclIUT5D7rlXOdg914apyO63-HlcsHRQJog';

const body: SetVendorRequest = {
  reportingAssetId: '62662df11c119c2164badd10',
  arrOfVendors: [
    {
      vendorId: '6400ab53a4acadb06a1e3bc6',
      productId: '63da524c64b6d636b88e9724',
      accountId: '1234',
      currency: 'USD',
    }
  ],
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await utilityController.setVendor(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

