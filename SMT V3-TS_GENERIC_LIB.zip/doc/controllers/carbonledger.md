# Carbonledger

```ts
const carbonledgerController = new CarbonledgerController(client);
```

## Class Name

`CarbonledgerController`

## Methods

* [Utility Dashboard](../../doc/controllers/carbonledger.md#utility-dashboard)
* [Utility Data](../../doc/controllers/carbonledger.md#utility-data)
* [Total Power](../../doc/controllers/carbonledger.md#total-power)
* [Utility Carbon Data](../../doc/controllers/carbonledger.md#utility-carbon-data)
* [Update Date](../../doc/controllers/carbonledger.md#update-date)
* [Quarterly Data](../../doc/controllers/carbonledger.md#quarterly-data)
* [Default Values](../../doc/controllers/carbonledger.md#default-values)
* [Carbon Ledger Random Data](../../doc/controllers/carbonledger.md#carbon-ledger-random-data)


# Utility Dashboard

```ts
async utilityDashboard(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3MzcyMDcyIiwiaWF0IjoxNjY3MzcyMDcyfQ.iHY0nrG1UV0AnIvTReaBozD66K4BISoJFXPk8hiyde5xpUJPGJlsm5TLRLjGGm2wr0N_PyLQHl5JLyF5PCC-DUA2Is8sFZ59GJ-OYlLpajTi6uGCkeqJ2JZQ3O1NsmjXNgsg-pqkl19zNc_fvaODuu5nFRz9UxeJW3pozCW0X1OJnsodXWmqfRHmZVN104NCqIgIrZ93ua5hSyF4Mt5JMD7Am2Jt759VGynp6mg0pYbYyJB4S_J0TZu93FdLC5BiJW8rs6BPEL2YkXB52cNHQsqZvx6jDayMrHBglJmAoNHGLMqNFx5M5vQQE9Vw51deKYbKUNan9UQUWTgHMGpRBg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await carbonLedgerController.utilityDashboard(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Utility Data

```ts
async utilityData(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3MzcyMDcyIiwiaWF0IjoxNjY3MzcyMDcyfQ.iHY0nrG1UV0AnIvTReaBozD66K4BISoJFXPk8hiyde5xpUJPGJlsm5TLRLjGGm2wr0N_PyLQHl5JLyF5PCC-DUA2Is8sFZ59GJ-OYlLpajTi6uGCkeqJ2JZQ3O1NsmjXNgsg-pqkl19zNc_fvaODuu5nFRz9UxeJW3pozCW0X1OJnsodXWmqfRHmZVN104NCqIgIrZ93ua5hSyF4Mt5JMD7Am2Jt759VGynp6mg0pYbYyJB4S_J0TZu93FdLC5BiJW8rs6BPEL2YkXB52cNHQsqZvx6jDayMrHBglJmAoNHGLMqNFx5M5vQQE9Vw51deKYbKUNan9UQUWTgHMGpRBg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await carbonLedgerController.utilityData(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Total Power

```ts
async totalPower(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3MzcyMDcyIiwiaWF0IjoxNjY3MzcyMDcyfQ.iHY0nrG1UV0AnIvTReaBozD66K4BISoJFXPk8hiyde5xpUJPGJlsm5TLRLjGGm2wr0N_PyLQHl5JLyF5PCC-DUA2Is8sFZ59GJ-OYlLpajTi6uGCkeqJ2JZQ3O1NsmjXNgsg-pqkl19zNc_fvaODuu5nFRz9UxeJW3pozCW0X1OJnsodXWmqfRHmZVN104NCqIgIrZ93ua5hSyF4Mt5JMD7Am2Jt759VGynp6mg0pYbYyJB4S_J0TZu93FdLC5BiJW8rs6BPEL2YkXB52cNHQsqZvx6jDayMrHBglJmAoNHGLMqNFx5M5vQQE9Vw51deKYbKUNan9UQUWTgHMGpRBg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await carbonLedgerController.totalPower(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Utility Carbon Data

```ts
async utilityCarbonData(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3MzcyMDcyIiwiaWF0IjoxNjY3MzcyMDcyfQ.iHY0nrG1UV0AnIvTReaBozD66K4BISoJFXPk8hiyde5xpUJPGJlsm5TLRLjGGm2wr0N_PyLQHl5JLyF5PCC-DUA2Is8sFZ59GJ-OYlLpajTi6uGCkeqJ2JZQ3O1NsmjXNgsg-pqkl19zNc_fvaODuu5nFRz9UxeJW3pozCW0X1OJnsodXWmqfRHmZVN104NCqIgIrZ93ua5hSyF4Mt5JMD7Am2Jt759VGynp6mg0pYbYyJB4S_J0TZu93FdLC5BiJW8rs6BPEL2YkXB52cNHQsqZvx6jDayMrHBglJmAoNHGLMqNFx5M5vQQE9Vw51deKYbKUNan9UQUWTgHMGpRBg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await carbonLedgerController.utilityCarbonData(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Update Date

```ts
async updateDate(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3MzcyMDcyIiwiaWF0IjoxNjY3MzcyMDcyfQ.iHY0nrG1UV0AnIvTReaBozD66K4BISoJFXPk8hiyde5xpUJPGJlsm5TLRLjGGm2wr0N_PyLQHl5JLyF5PCC-DUA2Is8sFZ59GJ-OYlLpajTi6uGCkeqJ2JZQ3O1NsmjXNgsg-pqkl19zNc_fvaODuu5nFRz9UxeJW3pozCW0X1OJnsodXWmqfRHmZVN104NCqIgIrZ93ua5hSyF4Mt5JMD7Am2Jt759VGynp6mg0pYbYyJB4S_J0TZu93FdLC5BiJW8rs6BPEL2YkXB52cNHQsqZvx6jDayMrHBglJmAoNHGLMqNFx5M5vQQE9Vw51deKYbKUNan9UQUWTgHMGpRBg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await carbonLedgerController.updateDate(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Quarterly Data

```ts
async quarterlyData(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3MzcyMDcyIiwiaWF0IjoxNjY3MzcyMDcyfQ.iHY0nrG1UV0AnIvTReaBozD66K4BISoJFXPk8hiyde5xpUJPGJlsm5TLRLjGGm2wr0N_PyLQHl5JLyF5PCC-DUA2Is8sFZ59GJ-OYlLpajTi6uGCkeqJ2JZQ3O1NsmjXNgsg-pqkl19zNc_fvaODuu5nFRz9UxeJW3pozCW0X1OJnsodXWmqfRHmZVN104NCqIgIrZ93ua5hSyF4Mt5JMD7Am2Jt759VGynp6mg0pYbYyJB4S_J0TZu93FdLC5BiJW8rs6BPEL2YkXB52cNHQsqZvx6jDayMrHBglJmAoNHGLMqNFx5M5vQQE9Vw51deKYbKUNan9UQUWTgHMGpRBg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await carbonLedgerController.quarterlyData(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Default Values

```ts
async defaultValues(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3MzcyMDcyIiwiaWF0IjoxNjY3MzcyMDcyfQ.iHY0nrG1UV0AnIvTReaBozD66K4BISoJFXPk8hiyde5xpUJPGJlsm5TLRLjGGm2wr0N_PyLQHl5JLyF5PCC-DUA2Is8sFZ59GJ-OYlLpajTi6uGCkeqJ2JZQ3O1NsmjXNgsg-pqkl19zNc_fvaODuu5nFRz9UxeJW3pozCW0X1OJnsodXWmqfRHmZVN104NCqIgIrZ93ua5hSyF4Mt5JMD7Am2Jt759VGynp6mg0pYbYyJB4S_J0TZu93FdLC5BiJW8rs6BPEL2YkXB52cNHQsqZvx6jDayMrHBglJmAoNHGLMqNFx5M5vQQE9Vw51deKYbKUNan9UQUWTgHMGpRBg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await carbonLedgerController.defaultValues(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Carbon Ledger Random Data

```ts
async carbonLedgerRandomData(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3MzcyMDcyIiwiaWF0IjoxNjY3MzcyMDcyfQ.iHY0nrG1UV0AnIvTReaBozD66K4BISoJFXPk8hiyde5xpUJPGJlsm5TLRLjGGm2wr0N_PyLQHl5JLyF5PCC-DUA2Is8sFZ59GJ-OYlLpajTi6uGCkeqJ2JZQ3O1NsmjXNgsg-pqkl19zNc_fvaODuu5nFRz9UxeJW3pozCW0X1OJnsodXWmqfRHmZVN104NCqIgIrZ93ua5hSyF4Mt5JMD7Am2Jt759VGynp6mg0pYbYyJB4S_J0TZu93FdLC5BiJW8rs6BPEL2YkXB52cNHQsqZvx6jDayMrHBglJmAoNHGLMqNFx5M5vQQE9Vw51deKYbKUNan9UQUWTgHMGpRBg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await carbonLedgerController.carbonLedgerRandomData(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

