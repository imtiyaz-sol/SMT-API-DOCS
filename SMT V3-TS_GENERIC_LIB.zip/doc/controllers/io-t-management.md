# Io T Management

```ts
const ioTManagementController = new IoTManagementController(client);
```

## Class Name

`IoTManagementController`

## Methods

* [Reporting Asset Management](../../doc/controllers/io-t-management.md#reporting-asset-management)
* [Get Productservice Names for Verification](../../doc/controllers/io-t-management.md#get-productservice-names-for-verification)
* [Get List of Reporting Assets](../../doc/controllers/io-t-management.md#get-list-of-reporting-assets)
* [I OT Manufacturer Info](../../doc/controllers/io-t-management.md#i-ot-manufacturer-info)
* [Update Io T Manufacture Status](../../doc/controllers/io-t-management.md#update-io-t-manufacture-status)


# Reporting Asset Management

```ts
async reportingAssetManagement(
  status: string,
  reportingAssetId: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string` | Query, Required | - |
| `reportingAssetId` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const status = 'OFFLINE';

const reportingAssetId = '62662df11c119c2164badd10';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY4MjA1NzUxNCIsImlhdCI6MTY4MjA1NzUxNH0.Jk6E2BdYx_lK38Ght3GGZ8PyE1lU2wTZMLAT3fMpncYdalWYlfMwYtufh--UZ_LQsTYmpafFVH84q9iKD6wQrcsZZHiTno2u2PQozymRPy--M7eWP3O1LE-KNBlyXu-t8kSP8cRP-KqI5nwWaJLBNS_3FIRsOHbHViWVE6OKcakV4xfAcnJpExvvaAhAH4sgfK6aVLLUR3naBaNqTYO_wgZTWEySAtRLhKc4tWXvRSuQhnRSuYSWY1mgE2K58ZAngg8Ns9Vb1OPNm9taFJCs_YeABa58EEK2KsXC7j4LEdtkNWHldJsnj_noncVO-4UzGjJ5bFXW8a5x8JP7cjvUzQ';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await ioTManagementController.reportingAssetManagement(
  status,
  reportingAssetId,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Get Productservice Names for Verification

```ts
async getProductserviceNamesForVerification(
  status: string,
  search: string,
  pageNumber: number,
  itemsPerPage: number,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string` | Query, Required | - |
| `search` | `string` | Query, Required | - |
| `pageNumber` | `number` | Query, Required | - |
| `itemsPerPage` | `number` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const status = 'ACCEPTED';

const search = 'Electricity';

const pageNumber = 1;

const itemsPerPage = 1;

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY4MjA1NzUxNCIsImlhdCI6MTY4MjA1NzUxNH0.Jk6E2BdYx_lK38Ght3GGZ8PyE1lU2wTZMLAT3fMpncYdalWYlfMwYtufh--UZ_LQsTYmpafFVH84q9iKD6wQrcsZZHiTno2u2PQozymRPy--M7eWP3O1LE-KNBlyXu-t8kSP8cRP-KqI5nwWaJLBNS_3FIRsOHbHViWVE6OKcakV4xfAcnJpExvvaAhAH4sgfK6aVLLUR3naBaNqTYO_wgZTWEySAtRLhKc4tWXvRSuQhnRSuYSWY1mgE2K58ZAngg8Ns9Vb1OPNm9taFJCs_YeABa58EEK2KsXC7j4LEdtkNWHldJsnj_noncVO-4UzGjJ5bFXW8a5x8JP7cjvUzQ';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await ioTManagementController.getProductserviceNamesForVerification(
  status,
  search,
  pageNumber,
  itemsPerPage,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Get List of Reporting Assets

```ts
async getListOfReportingAssets(
  status: string,
  pageNumber: number,
  itemsPerPage: number,
  search: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string` | Query, Required | - |
| `pageNumber` | `number` | Query, Required | - |
| `itemsPerPage` | `number` | Query, Required | - |
| `search` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const status = 'LIVE';

const pageNumber = 1;

const itemsPerPage = 16;

const search = 'Gridscale';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY4MjA2NzM0OCIsImlhdCI6MTY4MjA2NzM0OH0.jqFEDjgg-6mU0T6DO4QvJZYWC_DjE6-MtrfS5f_aWPmLeHE1BcQ_YvKUpuU7xJPVDsW-xTzPStzuk06peLpKUs8pTMEJ-x_gob0xMgyIZs1mwo3H2rIEzSz6kt-sVGNms6NYgh1Swsd8lr2INfZHcztVc5Qdzvex2VKdvEmygk7A2vZhaliaHU5a51f2WUAu_kYNvlQhSXAEYAKvcQuFkALkyS97QqAjyeVkC_jLSHm90RpBREAZP7P7XC3bwLbhP-k57PM8JHKWXSc-EvXbvyAqs-OjZ-RG065-xSN8Ff4SCytUnBASiVJCxa6x2JwMltibbM9TE6IxF88B957WdQ';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await ioTManagementController.getListOfReportingAssets(
  status,
  pageNumber,
  itemsPerPage,
  search,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# I OT Manufacturer Info

```ts
async iOTManufacturerInfo(
  itemsPerPage: number,
  pageNumber: number,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `itemsPerPage` | `number` | Query, Required | - |
| `pageNumber` | `number` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const itemsPerPage = 10;

const pageNumber = 1;

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIzQ0U1RThEQ0FGRENBMkFGNzU1OURBN0E4MDI3QjQ5NiIsInJvbGUiOiJEVCBNYW5hZ2VyL093bmVyIiwiY3JlYXRlZCI6IjE2ODI0OTkwNDYiLCJpYXQiOjE2ODI0OTkwNDd9.gfiXQWJya7wsppfyWLZVFthPimrk7YKXyMlcWkx7mOEkyq4WcxlWpmzf2BVbZPAyZjNC-aa2Q12Mv5_4XAVtrU_cyIyHz8wNGrrXYKDmydh1NmcPo5yV8GL_stkTcn5HM3TOAgGBtEGOfcJB1LNr5qTdzjlr3uMd0bgSS0vnJ2CRwleOmtMH6J00SUNDjDXR6348yJvwRmHr2qLn3dqs3cwgbtom_ruQQNDgJ47yE35aDSNfogu2v7kJi2JZVLkZy3-mUnlLlf_n5NhC6E3I3yZCUhqIj0ewfR88MI_1ojxo_uscMwjJwqTYtXAu95WV3VRP6D48oreDluPib6lBxw';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await ioTManagementController.iOTManufacturerInfo(
  itemsPerPage,
  pageNumber,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Update Io T Manufacture Status

```ts
async updateIoTManufactureStatus(
  authorization: string,
  body: UpdateIoTManufactureStatusRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`UpdateIoTManufactureStatusRequest`](../../doc/models/update-io-t-manufacture-status-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY4MjUwODg1NiIsImlhdCI6MTY4MjUwODg1Nn0.CLFu8WAZ1NBNi1kzMwZwyv1gpIn67HxQNSdqx-5gjs9vedUzUPJS56q4Qzv0e6tTgZ9_6OMsMysba8zznOhuiWIgC93o7wjy6nlVwGtGQC5L-lrSF5NHhcytwI5fK9ofx6vmUA8AcPVFj6_CT5OUvgTU04JamtsLmaK1v0C3iB2mi_37sMuhM5zNky2Cucmg8T_oebfBn11Z70hLvMvkK7hqI8-D6dzdvAm1wutcq57z0N8LhgKM5dBM10KMyROJc26pt7HUffMh_BxJsNInaevk6NpsbwbbmKWcyVJnfZx5MVwHzuE5R6rwcP0qzVRL7svxf3shDHUS5o_z4igHOQ';

const body: UpdateIoTManufactureStatusRequest = {
  manufacturerId: '644bb4b43718e16175e8c317',
  status: 'Accepted',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await ioTManagementController.updateIoTManufactureStatus(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

