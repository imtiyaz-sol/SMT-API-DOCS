# Toggle

```ts
const toggleController = new ToggleController(client);
```

## Class Name

`ToggleController`

## Methods

* [Toggle Asset Categories](../../doc/controllers/toggle.md#toggle-asset-categories)
* [Toggle Asset Types](../../doc/controllers/toggle.md#toggle-asset-types)
* [Toggle Sub-Asset Types](../../doc/controllers/toggle.md#toggle-sub-asset-types)
* [Toggle Reporting Assets](../../doc/controllers/toggle.md#toggle-reporting-assets)


# Toggle Asset Categories

```ts
async toggleAssetCategories(
  authorization: string,
  body: ToggleAssetCategoriesRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`ToggleAssetCategoriesRequest`](../../doc/models/toggle-asset-categories-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3OTQ2NDYxOSIsImlhdCI6MTY3OTQ2NDYxOX0.KFbHFykeU8iegiYeiZMVElrbYxmPi3ypqTcg7G30dGILSjDlpGbT3Zpu0V9DfKbvZNdSDzQ0i61KOpUnag-OjQbvYuUX2CEPhO6QP8HCUcR38xrKljDTznm3S4_pV6illPfyxohwzINVxxUgGi3s1yNfyunVEWiN6CRkhY7titsLmRBHYzeLMifbZ1jcSEiMBq8ShUKNTen4p6KFQjeSSAcBtng9iMyhl2qNfa-IuQELsBBeq98UBd0IgJhIWlVuKI5NgK9rHAHHzwC3pptexXP4creTEE6szrcX81kLR9xiEz9hxUxRMph7KjQ6BBvyfUCQUk66HoRppyMyjYkKpg';

const body: ToggleAssetCategoriesRequest = {
  status: 'Y',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await toggleController.toggleAssetCategories(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Toggle Asset Types

```ts
async toggleAssetTypes(
  authorization: string,
  body: ToggleAssetTypesRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`ToggleAssetTypesRequest`](../../doc/models/toggle-asset-types-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3OTQ2NDYxOSIsImlhdCI6MTY3OTQ2NDYxOX0.KFbHFykeU8iegiYeiZMVElrbYxmPi3ypqTcg7G30dGILSjDlpGbT3Zpu0V9DfKbvZNdSDzQ0i61KOpUnag-OjQbvYuUX2CEPhO6QP8HCUcR38xrKljDTznm3S4_pV6illPfyxohwzINVxxUgGi3s1yNfyunVEWiN6CRkhY7titsLmRBHYzeLMifbZ1jcSEiMBq8ShUKNTen4p6KFQjeSSAcBtng9iMyhl2qNfa-IuQELsBBeq98UBd0IgJhIWlVuKI5NgK9rHAHHzwC3pptexXP4creTEE6szrcX81kLR9xiEz9hxUxRMph7KjQ6BBvyfUCQUk66HoRppyMyjYkKpg';

const body: ToggleAssetTypesRequest = {
  status: 'Y',
  assetCategoryId: 'ALL',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await toggleController.toggleAssetTypes(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Toggle Sub-Asset Types

```ts
async toggleSubAssetTypes(
  authorization: string,
  body: ToggleSubAssetTypesRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`ToggleSubAssetTypesRequest`](../../doc/models/toggle-sub-asset-types-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3OTQ2NDYxOSIsImlhdCI6MTY3OTQ2NDYxOX0.KFbHFykeU8iegiYeiZMVElrbYxmPi3ypqTcg7G30dGILSjDlpGbT3Zpu0V9DfKbvZNdSDzQ0i61KOpUnag-OjQbvYuUX2CEPhO6QP8HCUcR38xrKljDTznm3S4_pV6illPfyxohwzINVxxUgGi3s1yNfyunVEWiN6CRkhY7titsLmRBHYzeLMifbZ1jcSEiMBq8ShUKNTen4p6KFQjeSSAcBtng9iMyhl2qNfa-IuQELsBBeq98UBd0IgJhIWlVuKI5NgK9rHAHHzwC3pptexXP4creTEE6szrcX81kLR9xiEz9hxUxRMph7KjQ6BBvyfUCQUk66HoRppyMyjYkKpg';

const body: ToggleSubAssetTypesRequest = {
  status: 'Y',
  assetCategoryId: 'ALL',
  assetTypeId: 'ALL',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await toggleController.toggleSubAssetTypes(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Toggle Reporting Assets

```ts
async toggleReportingAssets(
  authorization: string,
  body: ToggleReportingAssetsRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`ToggleReportingAssetsRequest`](../../doc/models/toggle-reporting-assets-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3OTQ2NDYxOSIsImlhdCI6MTY3OTQ2NDYxOX0.KFbHFykeU8iegiYeiZMVElrbYxmPi3ypqTcg7G30dGILSjDlpGbT3Zpu0V9DfKbvZNdSDzQ0i61KOpUnag-OjQbvYuUX2CEPhO6QP8HCUcR38xrKljDTznm3S4_pV6illPfyxohwzINVxxUgGi3s1yNfyunVEWiN6CRkhY7titsLmRBHYzeLMifbZ1jcSEiMBq8ShUKNTen4p6KFQjeSSAcBtng9iMyhl2qNfa-IuQELsBBeq98UBd0IgJhIWlVuKI5NgK9rHAHHzwC3pptexXP4creTEE6szrcX81kLR9xiEz9hxUxRMph7KjQ6BBvyfUCQUk66HoRppyMyjYkKpg';

const body: ToggleReportingAssetsRequest = {
  status: 'Y',
  assetCategoryId: 'ALL',
  assetTypeId: 'ALL',
  subAssetTypeId: 'ALL',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await toggleController.toggleReportingAssets(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

