# Io Tmanufacturer

```ts
const ioTmanufacturerController = new IoTmanufacturerController(client);
```

## Class Name

`IoTmanufacturerController`

## Methods

* [Io T Manufacturer List](../../doc/controllers/io-tmanufacturer.md#io-t-manufacturer-list)
* [Io T Manufacturer Information](../../doc/controllers/io-tmanufacturer.md#io-t-manufacturer-information)
* [Create Io T Manufacturer](../../doc/controllers/io-tmanufacturer.md#create-io-t-manufacturer)
* [Update Iot Manufacturer](../../doc/controllers/io-tmanufacturer.md#update-iot-manufacturer)
* [Delete Io T Manufacturer](../../doc/controllers/io-tmanufacturer.md#delete-io-t-manufacturer)


# Io T Manufacturer List

```ts
async ioTManufacturerList(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY4MjUwODg1NiIsImlhdCI6MTY4MjUwODg1Nn0.CLFu8WAZ1NBNi1kzMwZwyv1gpIn67HxQNSdqx-5gjs9vedUzUPJS56q4Qzv0e6tTgZ9_6OMsMysba8zznOhuiWIgC93o7wjy6nlVwGtGQC5L-lrSF5NHhcytwI5fK9ofx6vmUA8AcPVFj6_CT5OUvgTU04JamtsLmaK1v0C3iB2mi_37sMuhM5zNky2Cucmg8T_oebfBn11Z70hLvMvkK7hqI8-D6dzdvAm1wutcq57z0N8LhgKM5dBM10KMyROJc26pt7HUffMh_BxJsNInaevk6NpsbwbbmKWcyVJnfZx5MVwHzuE5R6rwcP0qzVRL7svxf3shDHUS5o_z4igHOQ';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await ioTManufacturerController.ioTManufacturerList(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Io T Manufacturer Information

```ts
async ioTManufacturerInformation(
  id: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const id = '641d37f7d66ec01fc0ffdcda';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NTA1MDQ0NSIsImlhdCI6MTY3NTA1MDQ0NX0.N5fkQn87ri8DWJoT4NneJG9I-3t0Yt9u1eCT011AoSct_eRfyH5dpYIP4MmBV-7Sr1A50TiBu2cT6gs16KkWsY9_aVKedFsiwj21KZB0srLFfp-h-NBRsV00v66VbGRhPnWH2_BnSmbuwEW66tcZMDeO2n8YLOYx4vRU7GsdFXCfsUn2ka5IfEt6hAlQtfMvG02boUa1pVL1jkkcYPvm1Z12HAlmsxUGALcJ0fNCF-jJFlqDAS97rz_Iu3Fz2NDgL5nGFpqI0sQqrALE5yLWpcEBRN6UIlNlxiOI1sOGsdPP5U9oV3iH9dcrJUBQSDldU6BwFow9nnm7k-9eNFLmIg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await ioTManufacturerController.ioTManufacturerInformation(
  id,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Create Io T Manufacturer

```ts
async createIoTManufacturer(
  authorization: string,
  body: CreateIoTManufacturerRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`CreateIoTManufacturerRequest`](../../doc/models/create-io-t-manufacturer-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY4MTg5OTk4NyIsImlhdCI6MTY4MTg5OTk4N30.dRLTwGvxAIljdLYMF1DqQyRAHgFD4JtRcdbw7XsOfMcXUlcG9lF-TXwD2S51EuC6nIW-3dXSXXlutYg7atxyQB4qQp6ZIkYTtyY_fkp-EjgOuydejm6eYWQqDaPdgNBhKNG3f3egkiiFrRmTvuILdKNCTyroQ4yDz9lIExV5_2rwODLt1Rsm4hbKnIj5GyNDaBhwODtkefLtmgc_T4nWv00yH6NphdCKXozPPwp4Q5TELFyl_zF6L6oTSh79fqZbJZ4x9ZnRute_kaTxQDnN32hG49i-eE1o1UYXyqzkyxCc3P0oGVwAZAd6nAop6iDWdMtJs0INdikWicjFtPtXLw';

const body: CreateIoTManufacturerRequest = {
  manufacturerName: 'kavin surya',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await ioTManufacturerController.createIoTManufacturer(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Update Iot Manufacturer

```ts
async updateIotManufacturer(
  iotManufacturerId: string,
  authorization: string,
  body: UpdateIotManufacturerRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `iotManufacturerId` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `body` | [`UpdateIotManufacturerRequest`](../../doc/models/update-iot-manufacturer-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const iotManufacturerId = '64461847ccff8b1a6fb81daf';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NTA1MDQ0NSIsImlhdCI6MTY3NTA1MDQ0NX0.N5fkQn87ri8DWJoT4NneJG9I-3t0Yt9u1eCT011AoSct_eRfyH5dpYIP4MmBV-7Sr1A50TiBu2cT6gs16KkWsY9_aVKedFsiwj21KZB0srLFfp-h-NBRsV00v66VbGRhPnWH2_BnSmbuwEW66tcZMDeO2n8YLOYx4vRU7GsdFXCfsUn2ka5IfEt6hAlQtfMvG02boUa1pVL1jkkcYPvm1Z12HAlmsxUGALcJ0fNCF-jJFlqDAS97rz_Iu3Fz2NDgL5nGFpqI0sQqrALE5yLWpcEBRN6UIlNlxiOI1sOGsdPP5U9oV3iH9dcrJUBQSDldU6BwFow9nnm7k-9eNFLmIg';

const body: UpdateIotManufacturerRequest = {
  manufacturerName: 'vvk',
  address: '',
  region: '',
  country: '',
  postalCode: '',
  vendorCode: '',
  accountContact: {
    name: 'Test',
    email: '',
    phone: '',
  },
  supportContact: {
    name: '',
    email: '',
    phone: '',
  },
  docs: {
    apiDoc: 'uploads/dummy-1682064978386.pdf',
    apiLink: 'https://www.test.com',
    legalDoc: 'uploads/dummy-1682064985447.pdf',
  },
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await ioTManufacturerController.updateIotManufacturer(
  iotManufacturerId,
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Delete Io T Manufacturer

```ts
async deleteIoTManufacturer(
  iotManufacturerId: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `iotManufacturerId` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const iotManufacturerId = '643fc31081d067235c58582c';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NTA1MDQ0NSIsImlhdCI6MTY3NTA1MDQ0NX0.N5fkQn87ri8DWJoT4NneJG9I-3t0Yt9u1eCT011AoSct_eRfyH5dpYIP4MmBV-7Sr1A50TiBu2cT6gs16KkWsY9_aVKedFsiwj21KZB0srLFfp-h-NBRsV00v66VbGRhPnWH2_BnSmbuwEW66tcZMDeO2n8YLOYx4vRU7GsdFXCfsUn2ka5IfEt6hAlQtfMvG02boUa1pVL1jkkcYPvm1Z12HAlmsxUGALcJ0fNCF-jJFlqDAS97rz_Iu3Fz2NDgL5nGFpqI0sQqrALE5yLWpcEBRN6UIlNlxiOI1sOGsdPP5U9oV3iH9dcrJUBQSDldU6BwFow9nnm7k-9eNFLmIg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await ioTManufacturerController.deleteIoTManufacturer(
  iotManufacturerId,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

