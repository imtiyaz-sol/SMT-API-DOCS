# Internal

```ts
const internalController = new InternalController(client);
```

## Class Name

`InternalController`

## Methods

* [Add Latitude and Longitude for FI Assets](../../doc/controllers/internal.md#add-latitude-and-longitude-for-fi-assets)
* [Update Reporting Asset Default Assets](../../doc/controllers/internal.md#update-reporting-asset-default-assets)


# Add Latitude and Longitude for FI Assets

```ts
async addLatitudeAndLongitudeForFIAssets(
  fiAssetId: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fiAssetId` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const fiAssetId = '1C67ECEDB2969E52E03F6472A60A577C';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3MzcyMDcyIiwiaWF0IjoxNjY3MzcyMDcyfQ.iHY0nrG1UV0AnIvTReaBozD66K4BISoJFXPk8hiyde5xpUJPGJlsm5TLRLjGGm2wr0N_PyLQHl5JLyF5PCC-DUA2Is8sFZ59GJ-OYlLpajTi6uGCkeqJ2JZQ3O1NsmjXNgsg-pqkl19zNc_fvaODuu5nFRz9UxeJW3pozCW0X1OJnsodXWmqfRHmZVN104NCqIgIrZ93ua5hSyF4Mt5JMD7Am2Jt759VGynp6mg0pYbYyJB4S_J0TZu93FdLC5BiJW8rs6BPEL2YkXB52cNHQsqZvx6jDayMrHBglJmAoNHGLMqNFx5M5vQQE9Vw51deKYbKUNan9UQUWTgHMGpRBg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await internalController.addLatitudeAndLongitudeForFIAssets(
  fiAssetId,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Update Reporting Asset Default Assets

```ts
async updateReportingAssetDefaultAssets(
  fiAssetId: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fiAssetId` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const fiAssetId = 'A4A29C28B27FE7254D57276728CFDCC9';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJBODg4RDE2MDFBNkI3MjU5MTBCQjQzQ0JBNUREQzhCNSIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY4MTIwNjk2MiIsImlhdCI6MTY4MTIwNjk2Mn0.BRAk38gfDAq0QHSIK6WfD2w1TcZeaS-CBaE93uOy-SjFNjOpJsgr5UmbibYKI6O0Q52L75x521lExzpIFGhyJG0t23dGvxb8PYuG4nWs72cJpMqe_MdQKo-xiI4KT6iVbQN-VWNPtFATAJeNy_k6pmcPD5g_HAq80-CAwEEowj0cay8RUQOWehiHfuT7Liggt-CXMSKYA4nSbPpob0lkNUoexuEWHWNQkIYn6ifvCKXnb053IvksCtEwJ-ZtV-jj6-hRgbnX5WRuB9QmQEgAumBnhqNVjkJAL3GpwZ2MV5UbTeF-rXdn-N980y_D961UaYvCD4Ohr_M8JYpjkv_GOw';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await internalController.updateReportingAssetDefaultAssets(
  fiAssetId,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

