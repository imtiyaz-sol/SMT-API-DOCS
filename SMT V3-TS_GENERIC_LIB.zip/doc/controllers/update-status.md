# Update Status

```ts
const updateStatusController = new UpdateStatusController(client);
```

## Class Name

`UpdateStatusController`

## Methods

* [Update Asset Category Status](../../doc/controllers/update-status.md#update-asset-category-status)
* [Update Asset Type Status](../../doc/controllers/update-status.md#update-asset-type-status)
* [Update Sub-Asset Type Status](../../doc/controllers/update-status.md#update-sub-asset-type-status)
* [Update Reporting Asset Type Status](../../doc/controllers/update-status.md#update-reporting-asset-type-status)


# Update Asset Category Status

```ts
async updateAssetCategoryStatus(
  authorization: string,
  body: UpdateAssetCategoryStatusRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`UpdateAssetCategoryStatusRequest`](../../doc/models/update-asset-category-status-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NzY4ODYzNyIsImlhdCI6MTY3NzY4ODYzN30.n6kyO9ajvzdUZCSyjdj03xaTCwhJQ9LeZEvKP0GgA5rgw5G3_2Azja99JSKjoGPO8lou0fMvJVbG9U3ScqWhY4FC2oghnpMn4A-ajlJGnZByDFkq2hS0QzAECkG6WG5P-Uk-HFH3DHz5v_iDfasDUXYcbsylLPJoPUksQOiIm3MRU6SAlQx2aJ2-z9oyeJd3ZHZNST7_ISvA9YGCTkAJmK9qrJ-qL6HwSdrPX63Kdkfy4KkpV0IlYIFcqe5gdWGzkgoFzyEU3KhFa004RgiyDebwmVz1bYWKsVNLZ3DqYmUD4DskuAcUHv4OseftZCTvR_1bXz5FK3xUmirJKvZkeA';

const body: UpdateAssetCategoryStatusRequest = {
  status: 'N',
  assetCategoryId: '6218a642dc5e3735ec198bc5',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await updateStatusController.updateAssetCategoryStatus(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Update Asset Type Status

```ts
async updateAssetTypeStatus(
  authorization: string,
  body: UpdateAssetTypeStatusRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`UpdateAssetTypeStatusRequest`](../../doc/models/update-asset-type-status-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJGQzA3QTc3Q0NGNTlFODg4QzNCMDZDN0YwRDZDMTc3QiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3Nzk0NTc4OSIsImlhdCI6MTY3Nzk0NTc4OX0.TthWQehosD5hnC-FeG_g03Vhb9nLHIsIVeIvfSA-wcLM8ku2S_bYmk_gHKhOi82oEf2TEp42QRoSTm-ozYwCiDvd_3xDYnZGQGe2wE5It73zd2Yd5V9qE2dc9q3zZp-m675ZCOoFEJtAup_Lstd5a5vZtbFq3HHiMQeLt3oOi7qV9YCfoeKF1i6kJdPrWc-rsg6cJpeFSyBb0m7hh82G_lSfTwldlQRW9suxbVNE8F75VTfDjM2tdYvHSSgjyzBlcVrX5dsE7shmGxT0x-aaiWKAwBQecBQMV9IX182BIDXWPc-nAE1TFJWOsUQ0uGtITkVZ7mgAFVny2yUUJJCaDg';

const body: UpdateAssetTypeStatusRequest = {
  status: 'Y',
  assetTypeId: '6218a649dc5e3735ec198cb1',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await updateStatusController.updateAssetTypeStatus(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Update Sub-Asset Type Status

```ts
async updateSubAssetTypeStatus(
  authorization: string,
  body: UpdateSubAssetTypeStatusRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`UpdateSubAssetTypeStatusRequest`](../../doc/models/update-sub-asset-type-status-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJGQzA3QTc3Q0NGNTlFODg4QzNCMDZDN0YwRDZDMTc3QiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3Nzk0NTc4OSIsImlhdCI6MTY3Nzk0NTc4OX0.TthWQehosD5hnC-FeG_g03Vhb9nLHIsIVeIvfSA-wcLM8ku2S_bYmk_gHKhOi82oEf2TEp42QRoSTm-ozYwCiDvd_3xDYnZGQGe2wE5It73zd2Yd5V9qE2dc9q3zZp-m675ZCOoFEJtAup_Lstd5a5vZtbFq3HHiMQeLt3oOi7qV9YCfoeKF1i6kJdPrWc-rsg6cJpeFSyBb0m7hh82G_lSfTwldlQRW9suxbVNE8F75VTfDjM2tdYvHSSgjyzBlcVrX5dsE7shmGxT0x-aaiWKAwBQecBQMV9IX182BIDXWPc-nAE1TFJWOsUQ0uGtITkVZ7mgAFVny2yUUJJCaDg';

const body: UpdateSubAssetTypeStatusRequest = {
  status: 'N',
  subAssetTypesId: '6218a66ddc5e3735ec198e0f',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await updateStatusController.updateSubAssetTypeStatus(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Update Reporting Asset Type Status

```ts
async updateReportingAssetTypeStatus(
  authorization: string,
  body: UpdateReportingAssetTypeStatusRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`UpdateReportingAssetTypeStatusRequest`](../../doc/models/update-reporting-asset-type-status-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = '{{token}}';

const body: UpdateReportingAssetTypeStatusRequest = {
  status: 'Y',
  assetId: '62662df11c119c2164badd26',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await updateStatusController.updateReportingAssetTypeStatus(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

