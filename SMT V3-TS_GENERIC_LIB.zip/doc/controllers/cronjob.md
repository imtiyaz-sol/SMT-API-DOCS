# Cronjob

```ts
const cronjobController = new CronjobController(client);
```

## Class Name

`CronjobController`

## Methods

* [Update Fi Asset Location](../../doc/controllers/cronjob.md#update-fi-asset-location)
* [Portfolio Dashboard Data](../../doc/controllers/cronjob.md#portfolio-dashboard-data)
* [Cooperate Gross Carbon](../../doc/controllers/cronjob.md#cooperate-gross-carbon)
* [Reporting Asset Graph Data](../../doc/controllers/cronjob.md#reporting-asset-graph-data)
* [Update Iot Devices](../../doc/controllers/cronjob.md#update-iot-devices)


# Update Fi Asset Location

```ts
async updateFiAssetLocation(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3MzcyMDcyIiwiaWF0IjoxNjY3MzcyMDcyfQ.iHY0nrG1UV0AnIvTReaBozD66K4BISoJFXPk8hiyde5xpUJPGJlsm5TLRLjGGm2wr0N_PyLQHl5JLyF5PCC-DUA2Is8sFZ59GJ-OYlLpajTi6uGCkeqJ2JZQ3O1NsmjXNgsg-pqkl19zNc_fvaODuu5nFRz9UxeJW3pozCW0X1OJnsodXWmqfRHmZVN104NCqIgIrZ93ua5hSyF4Mt5JMD7Am2Jt759VGynp6mg0pYbYyJB4S_J0TZu93FdLC5BiJW8rs6BPEL2YkXB52cNHQsqZvx6jDayMrHBglJmAoNHGLMqNFx5M5vQQE9Vw51deKYbKUNan9UQUWTgHMGpRBg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await cronJobController.updateFiAssetLocation(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Portfolio Dashboard Data

```ts
async portfolioDashboardData(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3MzcyMDcyIiwiaWF0IjoxNjY3MzcyMDcyfQ.iHY0nrG1UV0AnIvTReaBozD66K4BISoJFXPk8hiyde5xpUJPGJlsm5TLRLjGGm2wr0N_PyLQHl5JLyF5PCC-DUA2Is8sFZ59GJ-OYlLpajTi6uGCkeqJ2JZQ3O1NsmjXNgsg-pqkl19zNc_fvaODuu5nFRz9UxeJW3pozCW0X1OJnsodXWmqfRHmZVN104NCqIgIrZ93ua5hSyF4Mt5JMD7Am2Jt759VGynp6mg0pYbYyJB4S_J0TZu93FdLC5BiJW8rs6BPEL2YkXB52cNHQsqZvx6jDayMrHBglJmAoNHGLMqNFx5M5vQQE9Vw51deKYbKUNan9UQUWTgHMGpRBg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await cronJobController.portfolioDashboardData(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Cooperate Gross Carbon

```ts
async cooperateGrossCarbon(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3MzcyMDcyIiwiaWF0IjoxNjY3MzcyMDcyfQ.iHY0nrG1UV0AnIvTReaBozD66K4BISoJFXPk8hiyde5xpUJPGJlsm5TLRLjGGm2wr0N_PyLQHl5JLyF5PCC-DUA2Is8sFZ59GJ-OYlLpajTi6uGCkeqJ2JZQ3O1NsmjXNgsg-pqkl19zNc_fvaODuu5nFRz9UxeJW3pozCW0X1OJnsodXWmqfRHmZVN104NCqIgIrZ93ua5hSyF4Mt5JMD7Am2Jt759VGynp6mg0pYbYyJB4S_J0TZu93FdLC5BiJW8rs6BPEL2YkXB52cNHQsqZvx6jDayMrHBglJmAoNHGLMqNFx5M5vQQE9Vw51deKYbKUNan9UQUWTgHMGpRBg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await cronJobController.cooperateGrossCarbon(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Reporting Asset Graph Data

```ts
async reportingAssetGraphData(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3MzcyMDcyIiwiaWF0IjoxNjY3MzcyMDcyfQ.iHY0nrG1UV0AnIvTReaBozD66K4BISoJFXPk8hiyde5xpUJPGJlsm5TLRLjGGm2wr0N_PyLQHl5JLyF5PCC-DUA2Is8sFZ59GJ-OYlLpajTi6uGCkeqJ2JZQ3O1NsmjXNgsg-pqkl19zNc_fvaODuu5nFRz9UxeJW3pozCW0X1OJnsodXWmqfRHmZVN104NCqIgIrZ93ua5hSyF4Mt5JMD7Am2Jt759VGynp6mg0pYbYyJB4S_J0TZu93FdLC5BiJW8rs6BPEL2YkXB52cNHQsqZvx6jDayMrHBglJmAoNHGLMqNFx5M5vQQE9Vw51deKYbKUNan9UQUWTgHMGpRBg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await cronJobController.reportingAssetGraphData(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Update Iot Devices

```ts
async updateIotDevices(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3MzcyMDcyIiwiaWF0IjoxNjY3MzcyMDcyfQ.iHY0nrG1UV0AnIvTReaBozD66K4BISoJFXPk8hiyde5xpUJPGJlsm5TLRLjGGm2wr0N_PyLQHl5JLyF5PCC-DUA2Is8sFZ59GJ-OYlLpajTi6uGCkeqJ2JZQ3O1NsmjXNgsg-pqkl19zNc_fvaODuu5nFRz9UxeJW3pozCW0X1OJnsodXWmqfRHmZVN104NCqIgIrZ93ua5hSyF4Mt5JMD7Am2Jt759VGynp6mg0pYbYyJB4S_J0TZu93FdLC5BiJW8rs6BPEL2YkXB52cNHQsqZvx6jDayMrHBglJmAoNHGLMqNFx5M5vQQE9Vw51deKYbKUNan9UQUWTgHMGpRBg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await cronJobController.updateIotDevices(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

