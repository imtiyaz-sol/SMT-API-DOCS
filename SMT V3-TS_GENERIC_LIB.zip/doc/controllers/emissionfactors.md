# Emissionfactors

```ts
const emissionfactorsController = new EmissionfactorsController(client);
```

## Class Name

`EmissionfactorsController`


# Search

```ts
async search(
  year: number,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `year` | `number` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const year = 2021;

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3ODA0MDIwIiwiaWF0IjoxNjY3ODA0MDIwfQ.lYBiy1NAUcirNNrN2fk7RBVlqiMWOwqYHa3ZcnvmCpwdq_pSzZendR6l47SmF81oKmg0TQcMQm9hzZmZu-rvBsfLJ5iDJznUlvcbvJLwtnLl_jMK5zKCrrFdybnvVvR46R6C24OSDRslnrQoj8SxW2qwIDdwN_6tUmRoJD2GAsV4KIGy-w_hcjdzWXnXmXoK-4LIo-NzDJU4YKGQGw6lemaLescPiamBkXZ4G3K1zUjmlCD17JM2a_yoYwN6OUDYC6ZWN8ewvKwf4JasU92OUt2yOfyJ67eLwfBc8_YWCNmCWgQdSqs-dzO5J2nad9OSPrtyaOhU4C37p4JzFpwsHg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await emissionFactorsController.search(
  year,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

