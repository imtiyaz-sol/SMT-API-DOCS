# List

```ts
const listController = new ListController(client);
```

## Class Name

`ListController`

## Methods

* [Asset Category](../../doc/controllers/list.md#asset-category)
* [Asset Type](../../doc/controllers/list.md#asset-type)
* [Sub-Asset Type](../../doc/controllers/list.md#sub-asset-type)
* [Reporting Asset Type](../../doc/controllers/list.md#reporting-asset-type)


# Asset Category

```ts
async assetCategory(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = '{{token}}';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await listController.assetCategory(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Asset Type

```ts
async assetType(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJGQzA3QTc3Q0NGNTlFODg4QzNCMDZDN0YwRDZDMTc3QiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3Nzk0NTc4OSIsImlhdCI6MTY3Nzk0NTc4OX0.TthWQehosD5hnC-FeG_g03Vhb9nLHIsIVeIvfSA-wcLM8ku2S_bYmk_gHKhOi82oEf2TEp42QRoSTm-ozYwCiDvd_3xDYnZGQGe2wE5It73zd2Yd5V9qE2dc9q3zZp-m675ZCOoFEJtAup_Lstd5a5vZtbFq3HHiMQeLt3oOi7qV9YCfoeKF1i6kJdPrWc-rsg6cJpeFSyBb0m7hh82G_lSfTwldlQRW9suxbVNE8F75VTfDjM2tdYvHSSgjyzBlcVrX5dsE7shmGxT0x-aaiWKAwBQecBQMV9IX182BIDXWPc-nAE1TFJWOsUQ0uGtITkVZ7mgAFVny2yUUJJCaDg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await listController.assetType(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Sub-Asset Type

```ts
async subAssetType(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJGQzA3QTc3Q0NGNTlFODg4QzNCMDZDN0YwRDZDMTc3QiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3Nzk0NTc4OSIsImlhdCI6MTY3Nzk0NTc4OX0.TthWQehosD5hnC-FeG_g03Vhb9nLHIsIVeIvfSA-wcLM8ku2S_bYmk_gHKhOi82oEf2TEp42QRoSTm-ozYwCiDvd_3xDYnZGQGe2wE5It73zd2Yd5V9qE2dc9q3zZp-m675ZCOoFEJtAup_Lstd5a5vZtbFq3HHiMQeLt3oOi7qV9YCfoeKF1i6kJdPrWc-rsg6cJpeFSyBb0m7hh82G_lSfTwldlQRW9suxbVNE8F75VTfDjM2tdYvHSSgjyzBlcVrX5dsE7shmGxT0x-aaiWKAwBQecBQMV9IX182BIDXWPc-nAE1TFJWOsUQ0uGtITkVZ7mgAFVny2yUUJJCaDg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await listController.subAssetType(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Reporting Asset Type

```ts
async reportingAssetType(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = '{{token}}';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await listController.reportingAssetType(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

