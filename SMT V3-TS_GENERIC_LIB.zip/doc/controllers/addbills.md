# Addbills

```ts
const addbillsController = new AddbillsController(client);
```

## Class Name

`AddbillsController`


# Add Bills

```ts
async addBills(
  authorization: string,
  body: AddBillsRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`AddBillsRequest`](../../doc/models/add-bills-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3ODA0MDIwIiwiaWF0IjoxNjY3ODA0MDIwfQ.lYBiy1NAUcirNNrN2fk7RBVlqiMWOwqYHa3ZcnvmCpwdq_pSzZendR6l47SmF81oKmg0TQcMQm9hzZmZu-rvBsfLJ5iDJznUlvcbvJLwtnLl_jMK5zKCrrFdybnvVvR46R6C24OSDRslnrQoj8SxW2qwIDdwN_6tUmRoJD2GAsV4KIGy-w_hcjdzWXnXmXoK-4LIo-NzDJU4YKGQGw6lemaLescPiamBkXZ4G3K1zUjmlCD17JM2a_yoYwN6OUDYC6ZWN8ewvKwf4JasU92OUt2yOfyJ67eLwfBc8_YWCNmCWgQdSqs-dzO5J2nad9OSPrtyaOhU4C37p4JzFpwsHg';

const body: AddBillsRequest = {
  arrOfBills: [
    {
      reportingAssetNameId: '62662df11c119c2164badd10',
      utility: '63ff1075e84c9f1c0cf7df56',
      billStartDate: '1677609000',
      billEndDate: '1680114600',
      billLink: 'uploads/ElectricBills.v2-1680439820580.csv',
      billName: 'ElectricBills',
      billInfo: [
        {
          productionUnitId: '63da9f3e535c66a30db7dda8',
          billTotal: '454545',
          productId: '63da524c64b6d636b88e9724',
          accountNumber: 800863859,
        }
      ],
      fiAssetId: '080E329276C3D1FF06A344AEB0B15129',
      billAmount: 10,
      currency: 'USD',
    }
  ],
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await addBillsController.addBills(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

