# Setvendor

```ts
const setvendorController = new SetvendorController(client);
```

## Class Name

`SetvendorController`

## Methods

* [Country List](../../doc/controllers/setvendor.md#country-list)
* [State List](../../doc/controllers/setvendor.md#state-list)
* [Utility Bills](../../doc/controllers/setvendor.md#utility-bills)
* [Currency List](../../doc/controllers/setvendor.md#currency-list)
* [Get Currency Details](../../doc/controllers/setvendor.md#get-currency-details)


# Country List

```ts
async countryList(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3ODA0MDIwIiwiaWF0IjoxNjY3ODA0MDIwfQ.lYBiy1NAUcirNNrN2fk7RBVlqiMWOwqYHa3ZcnvmCpwdq_pSzZendR6l47SmF81oKmg0TQcMQm9hzZmZu-rvBsfLJ5iDJznUlvcbvJLwtnLl_jMK5zKCrrFdybnvVvR46R6C24OSDRslnrQoj8SxW2qwIDdwN_6tUmRoJD2GAsV4KIGy-w_hcjdzWXnXmXoK-4LIo-NzDJU4YKGQGw6lemaLescPiamBkXZ4G3K1zUjmlCD17JM2a_yoYwN6OUDYC6ZWN8ewvKwf4JasU92OUt2yOfyJ67eLwfBc8_YWCNmCWgQdSqs-dzO5J2nad9OSPrtyaOhU4C37p4JzFpwsHg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await setVendorController.countryList(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# State List

```ts
async stateList(
  countryName: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `countryName` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const countryName = 'Texas';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3ODA0MDIwIiwiaWF0IjoxNjY3ODA0MDIwfQ.lYBiy1NAUcirNNrN2fk7RBVlqiMWOwqYHa3ZcnvmCpwdq_pSzZendR6l47SmF81oKmg0TQcMQm9hzZmZu-rvBsfLJ5iDJznUlvcbvJLwtnLl_jMK5zKCrrFdybnvVvR46R6C24OSDRslnrQoj8SxW2qwIDdwN_6tUmRoJD2GAsV4KIGy-w_hcjdzWXnXmXoK-4LIo-NzDJU4YKGQGw6lemaLescPiamBkXZ4G3K1zUjmlCD17JM2a_yoYwN6OUDYC6ZWN8ewvKwf4JasU92OUt2yOfyJ67eLwfBc8_YWCNmCWgQdSqs-dzO5J2nad9OSPrtyaOhU4C37p4JzFpwsHg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await setVendorController.stateList(
  countryName,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Utility Bills

```ts
async utilityBills(
  fiAssetId: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fiAssetId` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const fiAssetId = '52E6B6C8EA8B0040F9D605F4B7A41393';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3ODA0MDIwIiwiaWF0IjoxNjY3ODA0MDIwfQ.lYBiy1NAUcirNNrN2fk7RBVlqiMWOwqYHa3ZcnvmCpwdq_pSzZendR6l47SmF81oKmg0TQcMQm9hzZmZu-rvBsfLJ5iDJznUlvcbvJLwtnLl_jMK5zKCrrFdybnvVvR46R6C24OSDRslnrQoj8SxW2qwIDdwN_6tUmRoJD2GAsV4KIGy-w_hcjdzWXnXmXoK-4LIo-NzDJU4YKGQGw6lemaLescPiamBkXZ4G3K1zUjmlCD17JM2a_yoYwN6OUDYC6ZWN8ewvKwf4JasU92OUt2yOfyJ67eLwfBc8_YWCNmCWgQdSqs-dzO5J2nad9OSPrtyaOhU4C37p4JzFpwsHg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await setVendorController.utilityBills(
  fiAssetId,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Currency List

```ts
async currencyList(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3ODA0MDIwIiwiaWF0IjoxNjY3ODA0MDIwfQ.lYBiy1NAUcirNNrN2fk7RBVlqiMWOwqYHa3ZcnvmCpwdq_pSzZendR6l47SmF81oKmg0TQcMQm9hzZmZu-rvBsfLJ5iDJznUlvcbvJLwtnLl_jMK5zKCrrFdybnvVvR46R6C24OSDRslnrQoj8SxW2qwIDdwN_6tUmRoJD2GAsV4KIGy-w_hcjdzWXnXmXoK-4LIo-NzDJU4YKGQGw6lemaLescPiamBkXZ4G3K1zUjmlCD17JM2a_yoYwN6OUDYC6ZWN8ewvKwf4JasU92OUt2yOfyJ67eLwfBc8_YWCNmCWgQdSqs-dzO5J2nad9OSPrtyaOhU4C37p4JzFpwsHg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await setVendorController.currencyList(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Get Currency Details

```ts
async getCurrencyDetails(
  authorization: string,
  body: GetCurrencyDetailsRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`GetCurrencyDetailsRequest`](../../doc/models/get-currency-details-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3ODA0MDIwIiwiaWF0IjoxNjY3ODA0MDIwfQ.lYBiy1NAUcirNNrN2fk7RBVlqiMWOwqYHa3ZcnvmCpwdq_pSzZendR6l47SmF81oKmg0TQcMQm9hzZmZu-rvBsfLJ5iDJznUlvcbvJLwtnLl_jMK5zKCrrFdybnvVvR46R6C24OSDRslnrQoj8SxW2qwIDdwN_6tUmRoJD2GAsV4KIGy-w_hcjdzWXnXmXoK-4LIo-NzDJU4YKGQGw6lemaLescPiamBkXZ4G3K1zUjmlCD17JM2a_yoYwN6OUDYC6ZWN8ewvKwf4JasU92OUt2yOfyJ67eLwfBc8_YWCNmCWgQdSqs-dzO5J2nad9OSPrtyaOhU4C37p4JzFpwsHg';

const body: GetCurrencyDetailsRequest = {
  reportingAssetId: '62662df11c119c2164badd10',
  vendorId: '63da971eaeee1d2f645d352d',
  productId: '63da524c64b6d636b88e9724',
  accountId: '12323243534',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await setVendorController.getCurrencyDetails(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

