# User

```ts
const userController = new UserController(client);
```

## Class Name

`UserController`

## Methods

* [User List](../../doc/controllers/user.md#user-list)
* [User Indormation](../../doc/controllers/user.md#user-indormation)
* [Update User](../../doc/controllers/user.md#update-user)
* [Create](../../doc/controllers/user.md#create)


# User List

```ts
async userList(
  firstName: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `firstName` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const firstName = 'darren';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NDU0MzY0MSIsImlhdCI6MTY3NDU0MzY0MX0.r60hiyvmugVO9Jn7OfkzW9vcDAYFNdQvdRoNpkEDZ6DiQT8rKuTIUt04ooi2dTvrGXJs75HfPmP7GSu9m7B3YDn92ilQOAcWbb7dxIy-XsgMMG7hYQxPvPKkoMuKQZmXxPcaeuKgoRO5O83lDNY0ZdX-GVs73Si6GMDu-yZYnSU_b7hnsi8ZPwo-YQjI3DOZeZNZW6rjjWVR7zjvgf3yp9gL1OftXfmY_9jKvlFKgBRkYh6_mropvhj7WKqtdE4fJJAIX35GGuyouqYaGnny4uo0bnzxxhaWTvQgNLYObdWRHwMQjdQWjwvk3Y8VVbCRaIwBG6Sf2URb6eDQL74p3g';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await userController.userList(
  firstName,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# User Indormation

```ts
async userIndormation(
  id: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const id = '631b8897e27fab409679b6b0';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NDU0MzY0MSIsImlhdCI6MTY3NDU0MzY0MX0.r60hiyvmugVO9Jn7OfkzW9vcDAYFNdQvdRoNpkEDZ6DiQT8rKuTIUt04ooi2dTvrGXJs75HfPmP7GSu9m7B3YDn92ilQOAcWbb7dxIy-XsgMMG7hYQxPvPKkoMuKQZmXxPcaeuKgoRO5O83lDNY0ZdX-GVs73Si6GMDu-yZYnSU_b7hnsi8ZPwo-YQjI3DOZeZNZW6rjjWVR7zjvgf3yp9gL1OftXfmY_9jKvlFKgBRkYh6_mropvhj7WKqtdE4fJJAIX35GGuyouqYaGnny4uo0bnzxxhaWTvQgNLYObdWRHwMQjdQWjwvk3Y8VVbCRaIwBG6Sf2URb6eDQL74p3g';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await userController.userIndormation(
  id,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Update User

```ts
async updateUser(
  authorization: string,
  body: UpdateUserRequest[],
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`UpdateUserRequest[]`](../../doc/models/update-user-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3OTk4MjU5NyIsImlhdCI6MTY3OTk4MjU5N30.bYWtkjMqoT4Fj5kzaxwIdmWhpb2W-TiUjicowVYQSjwrV2woHrGWRAdyNft-2ww1lQgr5V2QZItJbcHbiu8Tj4oK3sxSHpfLx3yoJFApzJncwikdNAwQsP03vEsx4e6b2i294PS1st1ZaB5CiYu7xCIiOoxBehog4TRGtmYmlAHekr0SbH8QhT0_jD8WPKJzjHFjmdkEzrg1SFMgRmmRzWSZHnO5dHAycHkunNkAqJcyibrM9YGTXqj0CC91dwUZQC5SfkAarE_KKAJHzRhlzGeAyOXMdSW-K_Bq5sQWtVyXwUT5VhTJEYWd9Kl0a3v2NtwHlQlwZx6Wvyrsfeu-9w';

const body: UpdateUserRequest[] = [
  {
    userId: 'E11D8EC62964DE8C0EAF967E432CEC01',
    permissionId: '99D2C25E64D8F2A0AF77976D39191B10',
    email: 'Varshilshah444@gmail.com',
    assetId: '62662df11c119c2164badd10',
  }
];

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await userController.updateUser(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Create

```ts
async create(
  authorization: string,
  body: Createrequest[],
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`Createrequest[]`](../../doc/models/createrequest.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3OTk4MjU5NyIsImlhdCI6MTY3OTk4MjU5N30.bYWtkjMqoT4Fj5kzaxwIdmWhpb2W-TiUjicowVYQSjwrV2woHrGWRAdyNft-2ww1lQgr5V2QZItJbcHbiu8Tj4oK3sxSHpfLx3yoJFApzJncwikdNAwQsP03vEsx4e6b2i294PS1st1ZaB5CiYu7xCIiOoxBehog4TRGtmYmlAHekr0SbH8QhT0_jD8WPKJzjHFjmdkEzrg1SFMgRmmRzWSZHnO5dHAycHkunNkAqJcyibrM9YGTXqj0CC91dwUZQC5SfkAarE_KKAJHzRhlzGeAyOXMdSW-K_Bq5sQWtVyXwUT5VhTJEYWd9Kl0a3v2NtwHlQlwZx6Wvyrsfeu-9w';

const body: Createrequest[] = [
  {
    firstName: 'Varshil',
    lastName: 'Shah',
    email: 'Varshilshah444@gmail.com',
    countryCode: '+91',
    phone: '9428712306',
    permissionId: 'B66784D18DBDA9EE962B52701DE014F7',
    assetId: '62662df11c119c2164badd10',
  }
];

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await userController.create(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

