# Production Unit

```ts
const productionUnitController = new ProductionUnitController(client);
```

## Class Name

`ProductionUnitController`

## Methods

* [Create Production Unit](../../doc/controllers/production-unit.md#create-production-unit)
* [Get Production Information](../../doc/controllers/production-unit.md#get-production-information)
* [Get Production Information List](../../doc/controllers/production-unit.md#get-production-information-list)


# Create Production Unit

```ts
async createProductionUnit(
  authorization: string,
  body: CreateProductionUnitRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`CreateProductionUnitRequest`](../../doc/models/create-production-unit-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NDU0MzY0MSIsImlhdCI6MTY3NDU0MzY0MX0.r60hiyvmugVO9Jn7OfkzW9vcDAYFNdQvdRoNpkEDZ6DiQT8rKuTIUt04ooi2dTvrGXJs75HfPmP7GSu9m7B3YDn92ilQOAcWbb7dxIy-XsgMMG7hYQxPvPKkoMuKQZmXxPcaeuKgoRO5O83lDNY0ZdX-GVs73Si6GMDu-yZYnSU_b7hnsi8ZPwo-YQjI3DOZeZNZW6rjjWVR7zjvgf3yp9gL1OftXfmY_9jKvlFKgBRkYh6_mropvhj7WKqtdE4fJJAIX35GGuyouqYaGnny4uo0bnzxxhaWTvQgNLYObdWRHwMQjdQWjwvk3Y8VVbCRaIwBG6Sf2URb6eDQL74p3g';

const body: CreateProductionUnitRequest = {
  unit: 'mT',
  vendorListId: '63cf8f115e37e4f4f71b29fd',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await productionUnitController.createProductionUnit(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Get Production Information

```ts
async getProductionInformation(
  productionUnitId: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productionUnitId` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const productionUnitId = '63cf9776b4bfc7267073114b';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NDU0MzY0MSIsImlhdCI6MTY3NDU0MzY0MX0.r60hiyvmugVO9Jn7OfkzW9vcDAYFNdQvdRoNpkEDZ6DiQT8rKuTIUt04ooi2dTvrGXJs75HfPmP7GSu9m7B3YDn92ilQOAcWbb7dxIy-XsgMMG7hYQxPvPKkoMuKQZmXxPcaeuKgoRO5O83lDNY0ZdX-GVs73Si6GMDu-yZYnSU_b7hnsi8ZPwo-YQjI3DOZeZNZW6rjjWVR7zjvgf3yp9gL1OftXfmY_9jKvlFKgBRkYh6_mropvhj7WKqtdE4fJJAIX35GGuyouqYaGnny4uo0bnzxxhaWTvQgNLYObdWRHwMQjdQWjwvk3Y8VVbCRaIwBG6Sf2URb6eDQL74p3g';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await productionUnitController.getProductionInformation(
  productionUnitId,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Get Production Information List

```ts
async getProductionInformationList(
  productionUnitId: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productionUnitId` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const productionUnitId = '63cf9776b4bfc7267073114b';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NDU0MzY0MSIsImlhdCI6MTY3NDU0MzY0MX0.r60hiyvmugVO9Jn7OfkzW9vcDAYFNdQvdRoNpkEDZ6DiQT8rKuTIUt04ooi2dTvrGXJs75HfPmP7GSu9m7B3YDn92ilQOAcWbb7dxIy-XsgMMG7hYQxPvPKkoMuKQZmXxPcaeuKgoRO5O83lDNY0ZdX-GVs73Si6GMDu-yZYnSU_b7hnsi8ZPwo-YQjI3DOZeZNZW6rjjWVR7zjvgf3yp9gL1OftXfmY_9jKvlFKgBRkYh6_mropvhj7WKqtdE4fJJAIX35GGuyouqYaGnny4uo0bnzxxhaWTvQgNLYObdWRHwMQjdQWjwvk3Y8VVbCRaIwBG6Sf2URb6eDQL74p3g';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await productionUnitController.getProductionInformationList(
  productionUnitId,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

