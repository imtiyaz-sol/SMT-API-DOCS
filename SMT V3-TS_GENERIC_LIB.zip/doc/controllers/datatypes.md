# Datatypes

```ts
const datatypesController = new DatatypesController(client);
```

## Class Name

`DatatypesController`

## Methods

* [Data Type List](../../doc/controllers/datatypes.md#data-type-list)
* [Data Type Information](../../doc/controllers/datatypes.md#data-type-information)


# Data Type List

```ts
async dataTypeList(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NTA1MDQ0NSIsImlhdCI6MTY3NTA1MDQ0NX0.N5fkQn87ri8DWJoT4NneJG9I-3t0Yt9u1eCT011AoSct_eRfyH5dpYIP4MmBV-7Sr1A50TiBu2cT6gs16KkWsY9_aVKedFsiwj21KZB0srLFfp-h-NBRsV00v66VbGRhPnWH2_BnSmbuwEW66tcZMDeO2n8YLOYx4vRU7GsdFXCfsUn2ka5IfEt6hAlQtfMvG02boUa1pVL1jkkcYPvm1Z12HAlmsxUGALcJ0fNCF-jJFlqDAS97rz_Iu3Fz2NDgL5nGFpqI0sQqrALE5yLWpcEBRN6UIlNlxiOI1sOGsdPP5U9oV3iH9dcrJUBQSDldU6BwFow9nnm7k-9eNFLmIg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await dataTypesController.dataTypeList(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Data Type Information

```ts
async dataTypeInformation(
  id: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const id = '6218a92a5814f72bbc27aea7';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NTA1MDQ0NSIsImlhdCI6MTY3NTA1MDQ0NX0.N5fkQn87ri8DWJoT4NneJG9I-3t0Yt9u1eCT011AoSct_eRfyH5dpYIP4MmBV-7Sr1A50TiBu2cT6gs16KkWsY9_aVKedFsiwj21KZB0srLFfp-h-NBRsV00v66VbGRhPnWH2_BnSmbuwEW66tcZMDeO2n8YLOYx4vRU7GsdFXCfsUn2ka5IfEt6hAlQtfMvG02boUa1pVL1jkkcYPvm1Z12HAlmsxUGALcJ0fNCF-jJFlqDAS97rz_Iu3Fz2NDgL5nGFpqI0sQqrALE5yLWpcEBRN6UIlNlxiOI1sOGsdPP5U9oV3iH9dcrJUBQSDldU6BwFow9nnm7k-9eNFLmIg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await dataTypesController.dataTypeInformation(
  id,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

