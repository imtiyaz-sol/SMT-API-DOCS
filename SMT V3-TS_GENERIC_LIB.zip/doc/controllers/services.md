# Services

```ts
const servicesController = new ServicesController(client);
```

## Class Name

`ServicesController`


# Upload File

```ts
async uploadFile(
  authorization: string,
  file: FileWrapper,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `file` | `FileWrapper` | Form, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3Njg3NDU5OSIsImlhdCI6MTY3Njg3NDU5OX0.smajQpJvGH36XRuo6L0JCHmpbKMUyYrOHcsl9OpJc0hnsoI8CkVObUNhxWhPhbOg43KVreAU3TG3JLdglakppZLx15sJFgWDUImrx7WHvqtD_o82RN6AcUkAMbkRv_bv_KZhWE12VBYx_XqcbYJx0W_5li96Qmew3UWwerXvjLM5o7FL9SNXD7Y810fWjjB4Eh1k3iKesIuFgRh1MzFDu2njNxao5HAymr7tZGJl2JzwnHScDLGdNTKdu-7M4LEgXFNpnfd8JR-IBGmSlzdvFNdwMcPRofsiQQYTw8AozuzPmMMFevYjEpWF1BLgGZWQpeAuzcXAZ7euPdON7wafUA';

const file = new FileWrapper(fs.createReadStream('dummy_file'));

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await servicesController.uploadFile(
  authorization,
  file
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

