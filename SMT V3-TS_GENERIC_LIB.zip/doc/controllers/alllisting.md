# Alllisting

```ts
const alllistingController = new AlllistingController(client);
```

## Class Name

`AlllistingController`

## Methods

* [Asset Types](../../doc/controllers/alllisting.md#asset-types)
* [Sub-Asset Types](../../doc/controllers/alllisting.md#sub-asset-types)
* [Reporting Asset Types](../../doc/controllers/alllisting.md#reporting-asset-types)


# Asset Types

```ts
async assetTypes(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJGQzA3QTc3Q0NGNTlFODg4QzNCMDZDN0YwRDZDMTc3QiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3Nzk0NTc4OSIsImlhdCI6MTY3Nzk0NTc4OX0.TthWQehosD5hnC-FeG_g03Vhb9nLHIsIVeIvfSA-wcLM8ku2S_bYmk_gHKhOi82oEf2TEp42QRoSTm-ozYwCiDvd_3xDYnZGQGe2wE5It73zd2Yd5V9qE2dc9q3zZp-m675ZCOoFEJtAup_Lstd5a5vZtbFq3HHiMQeLt3oOi7qV9YCfoeKF1i6kJdPrWc-rsg6cJpeFSyBb0m7hh82G_lSfTwldlQRW9suxbVNE8F75VTfDjM2tdYvHSSgjyzBlcVrX5dsE7shmGxT0x-aaiWKAwBQecBQMV9IX182BIDXWPc-nAE1TFJWOsUQ0uGtITkVZ7mgAFVny2yUUJJCaDg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await allListingController.assetTypes(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Sub-Asset Types

```ts
async subAssetTypes(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJGQzA3QTc3Q0NGNTlFODg4QzNCMDZDN0YwRDZDMTc3QiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3Nzk0NTc4OSIsImlhdCI6MTY3Nzk0NTc4OX0.TthWQehosD5hnC-FeG_g03Vhb9nLHIsIVeIvfSA-wcLM8ku2S_bYmk_gHKhOi82oEf2TEp42QRoSTm-ozYwCiDvd_3xDYnZGQGe2wE5It73zd2Yd5V9qE2dc9q3zZp-m675ZCOoFEJtAup_Lstd5a5vZtbFq3HHiMQeLt3oOi7qV9YCfoeKF1i6kJdPrWc-rsg6cJpeFSyBb0m7hh82G_lSfTwldlQRW9suxbVNE8F75VTfDjM2tdYvHSSgjyzBlcVrX5dsE7shmGxT0x-aaiWKAwBQecBQMV9IX182BIDXWPc-nAE1TFJWOsUQ0uGtITkVZ7mgAFVny2yUUJJCaDg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await allListingController.subAssetTypes(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Reporting Asset Types

```ts
async reportingAssetTypes(
  assetCategoryId: string,
  assetTypeNameId: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `assetCategoryId` | `string` | Query, Required | - |
| `assetTypeNameId` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const assetCategoryId = '6218a642dc5e3735ec198bc7';

const assetTypeNameId = '6218a649dc5e3735ec198c8d';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3ODE3MDg0NSIsImlhdCI6MTY3ODE3MDg0NX0.bIOAeGwJVxTinlxl_NtMlQrlEYhI7EN_witAfuhNwoWnE5wnBngSyjfou5se2trDQVdGGncPoMQxfeYnoHC2vcuHS4U6v7B4qQkf9GSH4UvemX0CARDGKXxuiwPMzCvGS0eATonM7CP9CptgnA92khoVKRP7DZupeLN5aOOQ5FZv-PTrYJMuZ5BcHpmLClr953ta4feWmoyLkq4bknUbCJSIJs6UNqGxj66DpsY5ZdVKR46lO29a5QREYPXWGLWDaQffEaJI-UDRYzxwwh5l6JqJzo48ADB7vnGItXc1NxB84Kcamq-xBT9K3LwzUDdVMgtnuQEV7_VQk4p7n-Hymw';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await allListingController.reportingAssetTypes(
  assetCategoryId,
  assetTypeNameId,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

