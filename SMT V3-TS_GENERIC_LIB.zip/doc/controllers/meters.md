# Meters

```ts
const metersController = new MetersController(client);
```

## Class Name

`MetersController`

## Methods

* [Get All Meters](../../doc/controllers/meters.md#get-all-meters)
* [Get Meter Info](../../doc/controllers/meters.md#get-meter-info)
* [Update Meter](../../doc/controllers/meters.md#update-meter)
* [Get Historical Collection](../../doc/controllers/meters.md#get-historical-collection)


# Get All Meters

```ts
async getAllMeters(
  token: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const token = '7575a671deaf49f4bae158c58a9a2338';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3Njg3NDU5OSIsImlhdCI6MTY3Njg3NDU5OX0.smajQpJvGH36XRuo6L0JCHmpbKMUyYrOHcsl9OpJc0hnsoI8CkVObUNhxWhPhbOg43KVreAU3TG3JLdglakppZLx15sJFgWDUImrx7WHvqtD_o82RN6AcUkAMbkRv_bv_KZhWE12VBYx_XqcbYJx0W_5li96Qmew3UWwerXvjLM5o7FL9SNXD7Y810fWjjB4Eh1k3iKesIuFgRh1MzFDu2njNxao5HAymr7tZGJl2JzwnHScDLGdNTKdu-7M4LEgXFNpnfd8JR-IBGmSlzdvFNdwMcPRofsiQQYTw8AozuzPmMMFevYjEpWF1BLgGZWQpeAuzcXAZ7euPdON7wafUA';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await metersController.getAllMeters(
  token,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Get Meter Info

```ts
async getMeterInfo(
  token: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const token = '97b51bfb8e69441da75ffd664f09eb9d';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3Njg3NDU5OSIsImlhdCI6MTY3Njg3NDU5OX0.smajQpJvGH36XRuo6L0JCHmpbKMUyYrOHcsl9OpJc0hnsoI8CkVObUNhxWhPhbOg43KVreAU3TG3JLdglakppZLx15sJFgWDUImrx7WHvqtD_o82RN6AcUkAMbkRv_bv_KZhWE12VBYx_XqcbYJx0W_5li96Qmew3UWwerXvjLM5o7FL9SNXD7Y810fWjjB4Eh1k3iKesIuFgRh1MzFDu2njNxao5HAymr7tZGJl2JzwnHScDLGdNTKdu-7M4LEgXFNpnfd8JR-IBGmSlzdvFNdwMcPRofsiQQYTw8AozuzPmMMFevYjEpWF1BLgGZWQpeAuzcXAZ7euPdON7wafUA';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await metersController.getMeterInfo(
  token,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Update Meter

```ts
async updateMeter(
  token: string,
  authorization: string,
  body: UpdateMeterRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `body` | [`UpdateMeterRequest`](../../doc/models/update-meter-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const token = '97b51bfb8e69441da75ffd664f09eb9d';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3Njg3NDU5OSIsImlhdCI6MTY3Njg3NDU5OX0.smajQpJvGH36XRuo6L0JCHmpbKMUyYrOHcsl9OpJc0hnsoI8CkVObUNhxWhPhbOg43KVreAU3TG3JLdglakppZLx15sJFgWDUImrx7WHvqtD_o82RN6AcUkAMbkRv_bv_KZhWE12VBYx_XqcbYJx0W_5li96Qmew3UWwerXvjLM5o7FL9SNXD7Y810fWjjB4Eh1k3iKesIuFgRh1MzFDu2njNxao5HAymr7tZGJl2JzwnHScDLGdNTKdu-7M4LEgXFNpnfd8JR-IBGmSlzdvFNdwMcPRofsiQQYTw8AozuzPmMMFevYjEpWF1BLgGZWQpeAuzcXAZ7euPdON7wafUA';

const body: UpdateMeterRequest = {
  isArchived: false,
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await metersController.updateMeter(
  token,
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Get Historical Collection

```ts
async getHistoricalCollection(
  token: string,
  authorization: string,
  body: GetHistoricalCollectionRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `body` | [`GetHistoricalCollectionRequest`](../../doc/models/get-historical-collection-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const token = '97b51bfb8e69441da75ffd664f09eb9d';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3Njg3NDU5OSIsImlhdCI6MTY3Njg3NDU5OX0.smajQpJvGH36XRuo6L0JCHmpbKMUyYrOHcsl9OpJc0hnsoI8CkVObUNhxWhPhbOg43KVreAU3TG3JLdglakppZLx15sJFgWDUImrx7WHvqtD_o82RN6AcUkAMbkRv_bv_KZhWE12VBYx_XqcbYJx0W_5li96Qmew3UWwerXvjLM5o7FL9SNXD7Y810fWjjB4Eh1k3iKesIuFgRh1MzFDu2njNxao5HAymr7tZGJl2JzwnHScDLGdNTKdu-7M4LEgXFNpnfd8JR-IBGmSlzdvFNdwMcPRofsiQQYTw8AozuzPmMMFevYjEpWF1BLgGZWQpeAuzcXAZ7euPdON7wafUA';

const body: GetHistoricalCollectionRequest = {
  meters: [
    '1263036'
  ],
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await metersController.getHistoricalCollection(
  token,
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

