# Authentication

```ts
const authenticationController = new AuthenticationController(client);
```

## Class Name

`AuthenticationController`

## Methods

* [Generate Mock Token](../../doc/controllers/authentication.md#generate-mock-token)
* [Decrypt Mock Token](../../doc/controllers/authentication.md#decrypt-mock-token)


# Generate Mock Token

```ts
async generateMockToken(
  body: GenerateMockTokenRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GenerateMockTokenRequest`](../../doc/models/generate-mock-token-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const body: GenerateMockTokenRequest = {
  userId: '8CB9348B055D25607AD45674CBF20A12',
  role: 'BCT Admin',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await authenticationController.generateMockToken(body);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Decrypt Mock Token

```ts
async decryptMockToken(
  body: DecryptMockTokenRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`DecryptMockTokenRequest`](../../doc/models/decrypt-mock-token-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const body: DecryptMockTokenRequest = {
  token: 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIzQ0U1RThEQ0FGRENBMkFGNzU1OURBN0E4MDI3QjQ5NiIsInJvbGUiOiJEVCBNYW5hZ2VyL093bmVyIiwiY3JlYXRlZCI6IjE2ODI0OTkwNDYiLCJpYXQiOjE2ODI0OTkwNDd9.gfiXQWJya7wsppfyWLZVFthPimrk7YKXyMlcWkx7mOEkyq4WcxlWpmzf2BVbZPAyZjNC-aa2Q12Mv5_4XAVtrU_cyIyHz8wNGrrXYKDmydh1NmcPo5yV8GL_stkTcn5HM3TOAgGBtEGOfcJB1LNr5qTdzjlr3uMd0bgSS0vnJ2CRwleOmtMH6J00SUNDjDXR6348yJvwRmHr2qLn3dqs3cwgbtom_ruQQNDgJ47yE35aDSNfogu2v7kJi2JZVLkZy3-mUnlLlf_n5NhC6E3I3yZCUhqIj0ewfR88MI_1ojxo_uscMwjJwqTYtXAu95WV3VRP6D48oreDluPib6lBxw',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await authenticationController.decryptMockToken(body);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

