# Data Management

```ts
const dataManagementController = new DataManagementController(client);
```

## Class Name

`DataManagementController`

## Methods

* [Manage Products](../../doc/controllers/data-management.md#manage-products)
* [Update Power Mix Values](../../doc/controllers/data-management.md#update-power-mix-values)


# Manage Products

```ts
async manageProducts(
  authorization: string,
  body: ManageProductsRequest[],
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`ManageProductsRequest[]`](../../doc/models/manage-products-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3ODM1MzYyMiIsImlhdCI6MTY3ODM1MzYyMn0.Q0rKGsrKxPASbArD-2ZcIajE_9j1IBPX1TR8tUmYErjrndynyfPjgdWbFqDoOIbigniCMdPLRaQHFs8c7VavFqITIlWtKycJT4r5OZ78_aE7MhOi-JeUsIKIPQzYcsMPqtvZcnk4NL3KaiA2-SGCjMrbUbvncMRuhEVzElWx-m6Q3cvH3uurKgcrPE4Su4HCuJt1Dy-wHJkPKVHq1ktQ2P87yAgFGIOZ2SHBTZcotHl_nwdZkeYrvRhdiY4OxDoXpjfT63ZpDS3PY7rLVMrl-7136Kyjlm4sMe_jwwoZgMaLx3oxKnqt8JBCnPQrRtA-z7yfUgpz0Degu5SjfE1nlw';

const body: ManageProductsRequest[] = [
  {
    manufacturerId: '63da971eaeee1d2f645d352d',
    productId: '63da525764b6d636b88e9728',
    manageFlag: false,
  },
  {
    manufacturerId: '63da972faeee1d2f645d3578',
    productId: '63da525764b6d636b88e9728',
    manageFlag: false,
  }
];

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await dataManagementController.manageProducts(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Update Power Mix Values

```ts
async updatePowerMixValues(
  authorization: string,
  body: UpdatePowerMixValuesRequest[],
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`UpdatePowerMixValuesRequest[]`](../../doc/models/update-power-mix-values-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4Q0I5MzQ4QjA1NUQyNTYwN0FENDU2NzRDQkYyMEExMiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3ODM1MzYyMiIsImlhdCI6MTY3ODM1MzYyMn0.Q0rKGsrKxPASbArD-2ZcIajE_9j1IBPX1TR8tUmYErjrndynyfPjgdWbFqDoOIbigniCMdPLRaQHFs8c7VavFqITIlWtKycJT4r5OZ78_aE7MhOi-JeUsIKIPQzYcsMPqtvZcnk4NL3KaiA2-SGCjMrbUbvncMRuhEVzElWx-m6Q3cvH3uurKgcrPE4Su4HCuJt1Dy-wHJkPKVHq1ktQ2P87yAgFGIOZ2SHBTZcotHl_nwdZkeYrvRhdiY4OxDoXpjfT63ZpDS3PY7rLVMrl-7136Kyjlm4sMe_jwwoZgMaLx3oxKnqt8JBCnPQrRtA-z7yfUgpz0Degu5SjfE1nlw';

const body: UpdatePowerMixValuesRequest[] = [
  {
    powerId: '63ff0f0fe84c9f1c0cf7d72b',
    totals: [
      {
        total1: {
          total: 100,
          coal: 0,
        },
      },
      {
        total2: {
          total: 100,
          coal: 0,
        },
      }
    ],
  }
];

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await dataManagementController.updatePowerMixValues(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

