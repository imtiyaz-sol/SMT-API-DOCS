# Vendor

```ts
const vendorController = new VendorController(client);
```

## Class Name

`VendorController`

## Methods

* [Vendor Information](../../doc/controllers/vendor.md#vendor-information)
* [Vendor List](../../doc/controllers/vendor.md#vendor-list)
* [Utiltiy Vendor List](../../doc/controllers/vendor.md#utiltiy-vendor-list)
* [Create Vendor](../../doc/controllers/vendor.md#create-vendor)
* [New Request](../../doc/controllers/vendor.md#new-request)
* [Delete Vendor](../../doc/controllers/vendor.md#delete-vendor)
* [Vendor Existence](../../doc/controllers/vendor.md#vendor-existence)


# Vendor Information

```ts
async vendorInformation(
  manufacturerId: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `manufacturerId` | `string` | Query, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const manufacturerId = '63b26d12dbc701047452b1ce';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await vendorController.vendorInformation(manufacturerId);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Vendor List

```ts
async vendorList(
  term: string,
  limit: number,
  skip: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `term` | `string` | Query, Required | - |
| `limit` | `number` | Query, Required | - |
| `skip` | `string` | Query, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const term = 'Test updat';

const limit = 10;

const skip = 'skip6';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await vendorController.vendorList(
  term,
  limit,
  skip
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Utiltiy Vendor List

```ts
async utiltiyVendorList(
  productServiceId: string,
  state: string,
  country: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productServiceId` | `string` | Query, Required | - |
| `state` | `string` | Query, Required | - |
| `country` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const productServiceId = '63da524c64b6d636b88e9724';

const state = 'New York';

const country = 'United States';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjEyIiwicm9sZSI6IkJDVCBBZG1pbiIsImNyZWF0ZWQiOiIxNjY3ODA0MDIwIiwiaWF0IjoxNjY3ODA0MDIwfQ.lYBiy1NAUcirNNrN2fk7RBVlqiMWOwqYHa3ZcnvmCpwdq_pSzZendR6l47SmF81oKmg0TQcMQm9hzZmZu-rvBsfLJ5iDJznUlvcbvJLwtnLl_jMK5zKCrrFdybnvVvR46R6C24OSDRslnrQoj8SxW2qwIDdwN_6tUmRoJD2GAsV4KIGy-w_hcjdzWXnXmXoK-4LIo-NzDJU4YKGQGw6lemaLescPiamBkXZ4G3K1zUjmlCD17JM2a_yoYwN6OUDYC6ZWN8ewvKwf4JasU92OUt2yOfyJ67eLwfBc8_YWCNmCWgQdSqs-dzO5J2nad9OSPrtyaOhU4C37p4JzFpwsHg';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await vendorController.utiltiyVendorList(
  productServiceId,
  state,
  country,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Create Vendor

```ts
async createVendor(
  authorization: string,
  body: CreateVendorRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`CreateVendorRequest`](../../doc/models/create-vendor-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NDQ1NzgwMCIsImlhdCI6MTY3NDQ1NzgwMH0.rKk2RhwWopIQOvQ4WXxmAUIrCuT3Xik19OBG7v3mo__d0QCXraQrWqwOX5gNftrDxX8BexMSN0kAshW6PdcgDGkiaFm-NL_-ImLr96kh4dsWcCPa7TYVf0-AcxbEqeY7QsYKkhahsezexAMlqOyTyDETUPapHlaETIakMCA6BwAhJpkh4ZAp9l-96m2a7KJcFy7wmrlcC1NtqVCe8w8l0-dtYnm0cYUGR_AQFgasYoWIFiOyw7vJ4V6yMg3HQShnVhegqlWfEf5OFUmb8NPmaUCh9oZkWb93L41NNzTBKGwReXBBJEOmR2OGExnk8LM0XC1w7n7rsPsrEH6j-ucbkg';

const body: CreateVendorRequest = {
  vendorInfo: {
    manufacturerName: 'Bermuda Electric Light Company',
    state: 'Hamilton',
  },
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await vendorController.createVendor(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# New Request

```ts
async newRequest(
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await vendorController.newRequest();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Delete Vendor

```ts
async deleteVendor(
  manufacturerId: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `manufacturerId` | `string` | Query, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const manufacturerId = '63b26d12dbc701047452b1ce';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await vendorController.deleteVendor(manufacturerId);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Vendor Existence

```ts
async vendorExistence(
  reportingAssetId: string,
  vendorId: string,
  productId: string,
  accountId: bigint,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reportingAssetId` | `string` | Query, Required | - |
| `vendorId` | `string` | Query, Required | - |
| `productId` | `string` | Query, Required | - |
| `accountId` | `bigint` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const reportingAssetId = '62662df11c119c2164badd10';

const vendorId = '63da971eaeee1d2f645d352d';

const productId = '63da524c64b6d636b88e9724';

const accountId = BigInt(12323243534);

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJGQzA3QTc3Q0NGNTlFODg4QzNCMDZDN0YwRDZDMTc3QiIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NzIzNjc0OSIsImlhdCI6MTY3NzIzNjc0OX0.sQt0nrFDgfR91PzSTaeMfhTsdI43vg33xWca4UerIVoS8QNkT6A6BfzhILLpmIwGSS-yjdVimsob0LHvQ1msUcVm8XBace24vttWHgfGRHwxbAuJe1G2qk-drtaz8Kw0Iso_I_5ldbmGLMw4GVw8lR0oBDUeJbgc7TYWNUfOav4OL2U2udM7CXHXZk8RqWVbjaiaXcWyQfDHtP_9lgpFM2fSrVYK6LsRQtlNOc6qxtIurnWKCFqi1dWSHM23WAA75v5d90Sq-Oc5is1Q7L9jhmzxHgtcgOI_wXhM50z5Nq6ad0tuSArVclIUT5D7rlXOdg914apyO63-HlcsHRQJog';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await vendorController.vendorExistence(
  reportingAssetId,
  vendorId,
  productId,
  accountId,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

