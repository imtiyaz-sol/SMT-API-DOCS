# Io Tmanufacturer Type

```ts
const ioTmanufacturerTypeController = new IoTmanufacturerTypeController(client);
```

## Class Name

`IoTmanufacturerTypeController`

## Methods

* [Io T Manufacturer Type Information](../../doc/controllers/io-tmanufacturer-type.md#io-t-manufacturer-type-information)
* [Io T Manufacturer Type List](../../doc/controllers/io-tmanufacturer-type.md#io-t-manufacturer-type-list)
* [Create Io T Manufacturer Type](../../doc/controllers/io-tmanufacturer-type.md#create-io-t-manufacturer-type)
* [Update Io T Manufacturer Type](../../doc/controllers/io-tmanufacturer-type.md#update-io-t-manufacturer-type)
* [Delete Io T Manufacturer Type](../../doc/controllers/io-tmanufacturer-type.md#delete-io-t-manufacturer-type)


# Io T Manufacturer Type Information

```ts
async ioTManufacturerTypeInformation(
  id: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const id = '6218a9c3676e6c0548cce448';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NDU0MzY0MSIsImlhdCI6MTY3NDU0MzY0MX0.r60hiyvmugVO9Jn7OfkzW9vcDAYFNdQvdRoNpkEDZ6DiQT8rKuTIUt04ooi2dTvrGXJs75HfPmP7GSu9m7B3YDn92ilQOAcWbb7dxIy-XsgMMG7hYQxPvPKkoMuKQZmXxPcaeuKgoRO5O83lDNY0ZdX-GVs73Si6GMDu-yZYnSU_b7hnsi8ZPwo-YQjI3DOZeZNZW6rjjWVR7zjvgf3yp9gL1OftXfmY_9jKvlFKgBRkYh6_mropvhj7WKqtdE4fJJAIX35GGuyouqYaGnny4uo0bnzxxhaWTvQgNLYObdWRHwMQjdQWjwvk3Y8VVbCRaIwBG6Sf2URb6eDQL74p3g';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await ioTManufacturerTypeController.ioTManufacturerTypeInformation(
  id,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Io T Manufacturer Type List

```ts
async ioTManufacturerTypeList(
  term: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `term` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const term = 'Anemometer';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NDU0MzY0MSIsImlhdCI6MTY3NDU0MzY0MX0.r60hiyvmugVO9Jn7OfkzW9vcDAYFNdQvdRoNpkEDZ6DiQT8rKuTIUt04ooi2dTvrGXJs75HfPmP7GSu9m7B3YDn92ilQOAcWbb7dxIy-XsgMMG7hYQxPvPKkoMuKQZmXxPcaeuKgoRO5O83lDNY0ZdX-GVs73Si6GMDu-yZYnSU_b7hnsi8ZPwo-YQjI3DOZeZNZW6rjjWVR7zjvgf3yp9gL1OftXfmY_9jKvlFKgBRkYh6_mropvhj7WKqtdE4fJJAIX35GGuyouqYaGnny4uo0bnzxxhaWTvQgNLYObdWRHwMQjdQWjwvk3Y8VVbCRaIwBG6Sf2URb6eDQL74p3g';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await ioTManufacturerTypeController.ioTManufacturerTypeList(
  term,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Create Io T Manufacturer Type

```ts
async createIoTManufacturerType(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NDU0MzY0MSIsImlhdCI6MTY3NDU0MzY0MX0.r60hiyvmugVO9Jn7OfkzW9vcDAYFNdQvdRoNpkEDZ6DiQT8rKuTIUt04ooi2dTvrGXJs75HfPmP7GSu9m7B3YDn92ilQOAcWbb7dxIy-XsgMMG7hYQxPvPKkoMuKQZmXxPcaeuKgoRO5O83lDNY0ZdX-GVs73Si6GMDu-yZYnSU_b7hnsi8ZPwo-YQjI3DOZeZNZW6rjjWVR7zjvgf3yp9gL1OftXfmY_9jKvlFKgBRkYh6_mropvhj7WKqtdE4fJJAIX35GGuyouqYaGnny4uo0bnzxxhaWTvQgNLYObdWRHwMQjdQWjwvk3Y8VVbCRaIwBG6Sf2URb6eDQL74p3g';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await ioTManufacturerTypeController.createIoTManufacturerType(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Update Io T Manufacturer Type

```ts
async updateIoTManufacturerType(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NDU0MzY0MSIsImlhdCI6MTY3NDU0MzY0MX0.r60hiyvmugVO9Jn7OfkzW9vcDAYFNdQvdRoNpkEDZ6DiQT8rKuTIUt04ooi2dTvrGXJs75HfPmP7GSu9m7B3YDn92ilQOAcWbb7dxIy-XsgMMG7hYQxPvPKkoMuKQZmXxPcaeuKgoRO5O83lDNY0ZdX-GVs73Si6GMDu-yZYnSU_b7hnsi8ZPwo-YQjI3DOZeZNZW6rjjWVR7zjvgf3yp9gL1OftXfmY_9jKvlFKgBRkYh6_mropvhj7WKqtdE4fJJAIX35GGuyouqYaGnny4uo0bnzxxhaWTvQgNLYObdWRHwMQjdQWjwvk3Y8VVbCRaIwBG6Sf2URb6eDQL74p3g';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await ioTManufacturerTypeController.updateIoTManufacturerType(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Delete Io T Manufacturer Type

```ts
async deleteIoTManufacturerType(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NDU0MzY0MSIsImlhdCI6MTY3NDU0MzY0MX0.r60hiyvmugVO9Jn7OfkzW9vcDAYFNdQvdRoNpkEDZ6DiQT8rKuTIUt04ooi2dTvrGXJs75HfPmP7GSu9m7B3YDn92ilQOAcWbb7dxIy-XsgMMG7hYQxPvPKkoMuKQZmXxPcaeuKgoRO5O83lDNY0ZdX-GVs73Si6GMDu-yZYnSU_b7hnsi8ZPwo-YQjI3DOZeZNZW6rjjWVR7zjvgf3yp9gL1OftXfmY_9jKvlFKgBRkYh6_mropvhj7WKqtdE4fJJAIX35GGuyouqYaGnny4uo0bnzxxhaWTvQgNLYObdWRHwMQjdQWjwvk3Y8VVbCRaIwBG6Sf2URb6eDQL74p3g';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await ioTManufacturerTypeController.deleteIoTManufacturerType(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

