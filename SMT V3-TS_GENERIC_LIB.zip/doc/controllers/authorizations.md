# Authorizations

```ts
const authorizationsController = new AuthorizationsController(client);
```

## Class Name

`AuthorizationsController`

## Methods

* [Get All Authorizations](../../doc/controllers/authorizations.md#get-all-authorizations)
* [Get Authorization Info](../../doc/controllers/authorizations.md#get-authorization-info)
* [Update Authorization](../../doc/controllers/authorizations.md#update-authorization)


# Get All Authorizations

```ts
async getAllAuthorizations(
  token: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const token = '97b51bfb8e69441da75ffd664f09eb9d';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3Njg3NDU5OSIsImlhdCI6MTY3Njg3NDU5OX0.smajQpJvGH36XRuo6L0JCHmpbKMUyYrOHcsl9OpJc0hnsoI8CkVObUNhxWhPhbOg43KVreAU3TG3JLdglakppZLx15sJFgWDUImrx7WHvqtD_o82RN6AcUkAMbkRv_bv_KZhWE12VBYx_XqcbYJx0W_5li96Qmew3UWwerXvjLM5o7FL9SNXD7Y810fWjjB4Eh1k3iKesIuFgRh1MzFDu2njNxao5HAymr7tZGJl2JzwnHScDLGdNTKdu-7M4LEgXFNpnfd8JR-IBGmSlzdvFNdwMcPRofsiQQYTw8AozuzPmMMFevYjEpWF1BLgGZWQpeAuzcXAZ7euPdON7wafUA';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await authorizationsController.getAllAuthorizations(
  token,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Get Authorization Info

```ts
async getAuthorizationInfo(
  token: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const token = '97b51bfb8e69441da75ffd664f09eb9d';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3Njg3NDU5OSIsImlhdCI6MTY3Njg3NDU5OX0.smajQpJvGH36XRuo6L0JCHmpbKMUyYrOHcsl9OpJc0hnsoI8CkVObUNhxWhPhbOg43KVreAU3TG3JLdglakppZLx15sJFgWDUImrx7WHvqtD_o82RN6AcUkAMbkRv_bv_KZhWE12VBYx_XqcbYJx0W_5li96Qmew3UWwerXvjLM5o7FL9SNXD7Y810fWjjB4Eh1k3iKesIuFgRh1MzFDu2njNxao5HAymr7tZGJl2JzwnHScDLGdNTKdu-7M4LEgXFNpnfd8JR-IBGmSlzdvFNdwMcPRofsiQQYTw8AozuzPmMMFevYjEpWF1BLgGZWQpeAuzcXAZ7euPdON7wafUA';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await authorizationsController.getAuthorizationInfo(
  token,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Update Authorization

```ts
async updateAuthorization(
  token: string,
  authorization: string,
  body: UpdateAuthorizationRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `token` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `body` | [`UpdateAuthorizationRequest`](../../doc/models/update-authorization-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const token = '97b51bfb8e69441da75ffd664f09eb9d';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3Njg3NDU5OSIsImlhdCI6MTY3Njg3NDU5OX0.smajQpJvGH36XRuo6L0JCHmpbKMUyYrOHcsl9OpJc0hnsoI8CkVObUNhxWhPhbOg43KVreAU3TG3JLdglakppZLx15sJFgWDUImrx7WHvqtD_o82RN6AcUkAMbkRv_bv_KZhWE12VBYx_XqcbYJx0W_5li96Qmew3UWwerXvjLM5o7FL9SNXD7Y810fWjjB4Eh1k3iKesIuFgRh1MzFDu2njNxao5HAymr7tZGJl2JzwnHScDLGdNTKdu-7M4LEgXFNpnfd8JR-IBGmSlzdvFNdwMcPRofsiQQYTw8AozuzPmMMFevYjEpWF1BLgGZWQpeAuzcXAZ7euPdON7wafUA';

const body: UpdateAuthorizationRequest = {
  nickname: 'Test authorization',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await authorizationsController.updateAuthorization(
  token,
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

