# Productservice

```ts
const productserviceController = new ProductserviceController(client);
```

## Class Name

`ProductserviceController`

## Methods

* [Create Product Service](../../doc/controllers/productservice.md#create-product-service)
* [Product Service List](../../doc/controllers/productservice.md#product-service-list)
* [Product Service Information](../../doc/controllers/productservice.md#product-service-information)


# Create Product Service

```ts
async createProductService(
  authorization: string,
  body: CreateProductServiceRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `body` | [`CreateProductServiceRequest`](../../doc/models/create-product-service-request.md) | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NDU0MzY0MSIsImlhdCI6MTY3NDU0MzY0MX0.r60hiyvmugVO9Jn7OfkzW9vcDAYFNdQvdRoNpkEDZ6DiQT8rKuTIUt04ooi2dTvrGXJs75HfPmP7GSu9m7B3YDn92ilQOAcWbb7dxIy-XsgMMG7hYQxPvPKkoMuKQZmXxPcaeuKgoRO5O83lDNY0ZdX-GVs73Si6GMDu-yZYnSU_b7hnsi8ZPwo-YQjI3DOZeZNZW6rjjWVR7zjvgf3yp9gL1OftXfmY_9jKvlFKgBRkYh6_mropvhj7WKqtdE4fJJAIX35GGuyouqYaGnny4uo0bnzxxhaWTvQgNLYObdWRHwMQjdQWjwvk3Y8VVbCRaIwBG6Sf2URb6eDQL74p3g';

const body: CreateProductServiceRequest = {
  productServiceName: 'Natural Gas',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await productServiceController.createProductService(
  authorization,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Product Service List

```ts
async productServiceList(
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NDU0MzY0MSIsImlhdCI6MTY3NDU0MzY0MX0.r60hiyvmugVO9Jn7OfkzW9vcDAYFNdQvdRoNpkEDZ6DiQT8rKuTIUt04ooi2dTvrGXJs75HfPmP7GSu9m7B3YDn92ilQOAcWbb7dxIy-XsgMMG7hYQxPvPKkoMuKQZmXxPcaeuKgoRO5O83lDNY0ZdX-GVs73Si6GMDu-yZYnSU_b7hnsi8ZPwo-YQjI3DOZeZNZW6rjjWVR7zjvgf3yp9gL1OftXfmY_9jKvlFKgBRkYh6_mropvhj7WKqtdE4fJJAIX35GGuyouqYaGnny4uo0bnzxxhaWTvQgNLYObdWRHwMQjdQWjwvk3Y8VVbCRaIwBG6Sf2URb6eDQL74p3g';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await productServiceController.productServiceList(authorization);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```


# Product Service Information

```ts
async productServiceInformation(
  productServiceId: string,
  authorization: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<void>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productServiceId` | `string` | Query, Required | - |
| `authorization` | `string` | Header, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`void`

## Example Usage

```ts
const productServiceId = '63da524c64b6d636b88e9724';

const authorization = 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMTIsInJvbGUiOiJCQ1QgQWRtaW4iLCJjcmVhdGVkIjoiMTY3NDU0MzY0MSIsImlhdCI6MTY3NDU0MzY0MX0.r60hiyvmugVO9Jn7OfkzW9vcDAYFNdQvdRoNpkEDZ6DiQT8rKuTIUt04ooi2dTvrGXJs75HfPmP7GSu9m7B3YDn92ilQOAcWbb7dxIy-XsgMMG7hYQxPvPKkoMuKQZmXxPcaeuKgoRO5O83lDNY0ZdX-GVs73Si6GMDu-yZYnSU_b7hnsi8ZPwo-YQjI3DOZeZNZW6rjjWVR7zjvgf3yp9gL1OftXfmY_9jKvlFKgBRkYh6_mropvhj7WKqtdE4fJJAIX35GGuyouqYaGnny4uo0bnzxxhaWTvQgNLYObdWRHwMQjdQWjwvk3Y8VVbCRaIwBG6Sf2URb6eDQL74p3g';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await productServiceController.productServiceInformation(
  productServiceId,
  authorization
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

